# Binding and evidence completeness

**Repository binding.** GitHub コネクタで `chemitaro/code-structure-viz` の対象 ref `refs/heads/iss-00008-generate-nextjs-component-snapshots` を直接取得し、branch endpoint と Git ref endpoint の双方が full tip object ID `58864bf0223e35c6cf31ca09b0d9040954e3d9cc` を返した。これは `expected_sha` と byte-for-byte で一致する。対象 commit の tree は `234389af2350faa8edd93b8afe2acadebcdb69f6` である。他 branch の内容は分析に使用していない。 

**Candidate／review binding.** Current candidate と reviewed SHA はともに `58864bf0223e35c6cf31ca09b0d9040954e3d9cc`。固定 unit point は `caf38329826ae34f8e3cb330b83b97e0357b7dc5` で、review 対象はそこから candidate までの累積 unit である。Review source は ChatGPT Code Review Strict の native session `issue8-si04-full-core-58864bf`、reviewer conversation は `6ac03f58-17e8-83e8-b469-0c0b5010d7b6`。結果 artifact は `.workbench/luna-max-implement/issue8-nextjs-snapshots/reviews/si04-full-core-58864bf.result.json`、packet 記載 SHA-256 は `040560ee8ee23fe3ee420dbfbb6cdf61f1afebd2d089d2bdbc27ca068f71ecb2`、log digest は `ead25d483f4231e14caeaebe1b91b1b7119409fccf2cde5e06f7b7a0496b6052` である。完全な validated JSON は packet 内に保存され、`review_status=fail`、R1=P1、R2=P2 の source-native classification を保持している。attachments-bundle attachments-bundle

**Reviewer provenance.** Packet は reviewer invocation を `gpt-5.6-sol`／`extra-high` と記録し、native UI picker が `GPT-5.6 Sol` と `Extra High` をそれぞれ verified=true で観測したとしている。これは UI picker の直接観測であって backend attestation ではない。attachments-bundle

**Analyst provenance and continuity.** Analysis identity は `issue8-si04-source-locality-findings`。本セッションは既存 analyst lineage を再利用しない fresh・independent・initial 分析であり、continuity mode は fresh initial である。現在の analyst は GPT-5.6 Sol Pro。retained reviewer conversation、SI-03 analyst、author session は analyst lineage として採用していない。

**Reviewed／tested SHA alignment.**

- Fresh locality probe は clean exact candidate `58864bf...` 上で完了しており、R1 の current behavior を直接観測している。
- 元の Core／回帰／schema／lint／type-check jobs は terminal だが、process 自体は parent HEAD `c759f3da...` で開始された。三つの tested Core files はその後変更されず、candidate では documentation evidence のみが追加されたため、これは **same-content evidence** であり、test process が `58864bf...` から開始したという証拠ではない。
- Reviewer 自身は test を実行していない。attachments-bundle attachments-bundle

**Evidence freshness.** Review は `2026-10-02T23:52:19.345Z` に完了し、evidence collection は `2026-10-02T23:53Z` 以降。review、local validation、probe の producer はすべて terminal である。attachments-bundle

**Packet completeness judgment.** R1 の semantic disposition、blocking effect、root cause、authorized response を決めるには十分であり、semantic analysis を開始できる complete current batch と判断する。以下の material gaps は残るが、推測で埋めない。

1. **CG-SI04-01:** 既存 green suite は nonprogram reverse importer を含む R1 ケースを持たず、誤った `partial_safe` を検出していない。
2. **CG-SI04-02:** R2 は実コードの control/data path と source graph reachability までは追跡済みだが、reverse-only importer の正規 taint／partition と独立 normal open edge を同時に持つ完全な Core-valid fixture が実行されていない。したがって end-to-end regression の直接実行証拠はない。attachments-bundle
3. Review result JSON と log の digest は packet-supplied であり、本 analyst は原 raw log の digest を再計算していない。ただし complete validated JSON 本文は packet に含まれる。
4. 元 aggregate jobs は final SHA での process-start evidence ではない。修復後は新 full SHA に結び直す必要がある。
5. all-contract/full suite、whole A02、actual TypeScript、OS process、CLI、publication、SI-05 以降は意図的な scope 外であり、欠落した SI-04 証拠として扱わない。attachments-bundle

# Executive disposition

**Batch disposition: SI-04 は BLOCKED。RG-SI04-01 に対する限定的 `implementation-remediation` は既存 authority から一意に決まり、親の P1 修復権限内で実装可能である。**

R1 `[P1] 非programの逆importerをlocalized扱いしない` は有効で、実 trigger は到達可能、current candidate 上で再現済みである。`src/global.d.ts -> src/value.ts` が同じ seal の resolved edge であるにもかかわらず、context File は untainted のまま safe File projection に残り、Core は `localized=true`、`partial_safe`、`payload_available=true` を返し、independent decision validator も同じ結果を受理する。parse_file／read_file の双方で観測されている。attachments-bundle

親 policy では P0/P1 と `review_status=fail` が current SI-04 certification を block し、fresh passing SI-04 review まで SI-05 は閉じる。よって R1 は blocking。R1 の修正は classification だけから自動的に許可されるのではなく、packet に記録された「unchanged authority 下の最小 P0/P1 correction」を許す親 authorization に基づく。attachments-bundle

R2 `[P2] 逆importerの通常open edgeだけでSOURCE-003にしない` は、実装上の forward／reverse predicate の差異として支持されるが、完全な Core-valid compound fixture は未実行である。source-native P2 を維持し、blocking へ昇格しない。親 policy 上は report-only であり、今回の修復 handoff に含めない。

したがって、**安全な progress は「R1 のみを修復する bounded implementation」までは可能**である。一方、SI-04 certification、SI-05、production、publication へ進むことは現時点では不可能である。

# Root-cause groups

## RG-SI04-01 — reverse failure closure と public File projection の照合欠落

**Mapped items**

- `R1`, source-native classification `P1`
- `CG-SI04-01`, nonprogram reverse importer の回帰 coverage 欠落

**Shared invariant.** `parse_file`／`read_file` failure の reverse closure に属する File が、合法な owner-closed partition 後も available public File projection に残る場合、その subset は独立とは立証されていない。File taint、偽 Module、逆 causal edgeを発明せず、Core locality を `false` として `CSV-NEXT-SOURCE-003`／payload unavailable に閉じなければならない。

**Root cause.** `derive_post_acquisition_locality_v3` は reverse closure を計算する一方、reverse importer の typed taint を `module_rows` に存在する path についてしか検査しない。Module を持たない nonprogram context File は検査対象外となり、public File projection との交差も確認されない。

## RG-SI04-02 — ordinary open-edge 判定で forward と reverse を一つの集合に潰している

**Mapped items**

- `R2`, source-native classification `P2`
- `CG-SI04-02`, fully Core-valid compound fixture／fresh execution の欠落

**Shared invariant.** 通常 open edge の locality impact は failed File からの forward reachability 上で評価し、`module_plane` のみを graph-global fail-closed とする。reverse failure closure は importer の除外・安全 projection 判定に使うが、その importer が持つ独立した通常 open edgeを、それだけで failed File の nonlocal dependency としてはならない。

**Root cause.** Current implementation は `affected = forward closure ∪ reverse closure` とし、通常 open edge の source がこの union に入るだけで `open_dependency=true` とする。このため forward dependency と reverse invalidation の意味が失われている。

## Deliberate non-grouping

RG-SI04-01 と RG-SI04-02 は同じ helper 内にあり、広義には retained ledger semantics の不完全な移植という共通背景を持つ。しかし、次の理由で一群にはしない。

- R1 は unsafe availability、R2 は availability regression と影響方向が逆。
- R1 は P1 blocking、R2 は P2 report-only。
- R1 は public File projection との交差 predicate を追加するだけで、R2 の open-edge predicate を変更せず修正できる。
- 一群にすると P1 authorization を利用して P2 behavior まで暗黙に変更する危険がある。

# Detailed adjudication

## RG-SI04-01 / R1

**Claim validity.** 有効。current code、same-seal graph、owner-closed source projection、fresh probe が一致している。Current helper は reverse closure を計算するが、taint check を Module paths に限定し、その後 `target_tainted` と open edge だけから `localized` を決めている。

**Trigger reachability.** 到達可能。Production source graph owner は `.js/.jsx/.ts/.tsx` に加えて `.d.ts` context files も scan し、literal static import を resolved edge または normal open edgeに変換する。したがって `src/global.d.ts -> src/value.ts` は synthetic graph substitution ではなく actual seal graph で成立する。 

**Observed current effect.** parse_file と read_file の両ケースで、`src/global.d.ts` は `roles=["context"]`、`taints=[]`、reverse closure 内、safe File projection 内のまま、`localized=true`、`partial_safe`、`payload_available=true` となる。independent controls は同じ context File を保持しつつ reverse edge がなく、正しく `partial_safe` のままである。attachments-bundle

**In-scope impact.** Failure closure 内の File が available safe projection に残るため、SI-04 の complete full-proof／source-locality guarantee を破り、独立性を立証できていない payload を公開可能にする。

**Blocking effect.** P1 かつ required review gate が fail なので SI-04 certification を block。SI-05 も block。severity は変更しない。

**Violated authority and exact proposition.**

- Accepted design は nonprogram File を untainted なら必ず publication-eligible とし、Module→File／File→Project の逆 taint edgeを追加しない。source-safe と public eligibility を別に扱う。
- Admission-v3 は同一 seal の graph、failure closure、target-taint について既存 `SourceFailureLedger.from_seal` の意味を維持し、safe subset だけでは partial-safe を認定しないと定める。
- Retained ledger は reverse importer を `failure_closure_paths` に含め、`safe_file_set` から除く。新 owner-closed partition では合法的に除外できない nonprogram File が残るため、対応する Core outcome は SOURCE-003 でなければならない。
- Exact unsatisfied proposition は、**「failure reverse closure と available public File projection は交差してはならない。合法 partition で交差を除去できない場合、locality は不成立である」**。

**First incorrect fault layer.** `implementation`。Requirement、Design、admission contract、retained ledger semantics は同時に満たせ、意味の衝突はない。`test` layer の missing case は欠陥流出を許した二次的 coverage gap。

**Primary response route.** `implementation-remediation`。

**Guarantees preserved.**

- source seal、source graph、actual source bytes、graph digest
- File／Module taint規則と owner-closed partition
- nonprogram File に Module、taint、逆 causal edgeを発明しないこと
- independent safe-side controls の `partial_safe`
- target failure、record-limit、SOURCE、entity-budget の既存順序
- independent validator による actual owner 再導出
- public schema、compatibility、data、security、migration、operation guarantees

**Guarantee changed.** Reverse failure closure 内に publication-eligible File が残るケースだけ、`localized=true`／available から `localized=false`／`CSV-NEXT-SOURCE-003`／payload unavailable へ変える。

**Missing evidence.** Product behavior の claim に不足はない。欠けているのは durable first-red regression test と、fixed full SHA に結び付いた Green／aggregate／fresh review evidence である。

## RG-SI04-02 / R2

**Claim validity.** Predicate-level mismatch は成立している。Retained ledger は通常 open edge の source を failed root の forward `reached` に対して確認し、`module_plane` だけを global に扱う。Current helper は forward と reverse の union に対して通常 open edge を確認する。 

**Trigger reachability.** Graph layer では到達可能。Actual scanner は literal static import を認識し、解決不能な relative import／package import を normal open edge として生成する。 

**Evidence limit.** 「C が reverse-only importer で、正規 proof により tainted/excluded され、同時に C が独立した normal open edge を持つ」という compound fixture は fresh Core execution されていない。このため exact end-to-end gate outcome は未実証である。Packet 自身もこの制限を明示している。attachments-bundle

**In-scope impact.** 成立時は、本来 publication 可能な独立 safe side B まで SOURCE-003 に落とす availability regression。unsafe publication ではない。

**Blocking effect.** Source-native P2。親 policy により report-only、non-blocking。P1 への昇格や repair authorization は行わない。

**Violated authority and exact proposition.** Admission-v3 が維持するとした retained ledger semantics に対し、**「normal open edge は forward failure reachability 上だけで locality を破る。reverse-only importer の別 open edge は単独では nonlocal にしない。一方 `module_plane` は global fail-closed を維持する」**という proposition を current predicate が表現していない。

**First incorrect fault layer.** `implementation`。ただし end-to-end trigger 証拠の不足は `test` layer の coverage gap。

**Primary response route.** 設計上は `implementation-remediation`。ただし現在の parent authorization では実行不可であり、別の明示 task と first-red evidence が必要。

**Guarantees to preserve if later authorized.**

- `module_plane` の global fail-closed
- forward-reached normal open edge の SOURCE-003
- reverse closure による importer invalidation
- RG-SI04-01 の reverse/public intersection guard
- target-taint、same-seal graph、owner-closed projection

**Changed guarantee if later authorized.** Reverse-only importer が持つ独立 normal open edgeだけでは、safe-side availability を失わせない。

# Integrated response design

Current parent response は **RG-SI04-01 のみ**を対象とする。

1. `derive_post_acquisition_locality_v3` 内で、各 parse/read root の `reverse_reached` を現行どおり same-seal graph から導出する。
2. Candidate の実際の validated publication view に含まれる public File paths を導出する。caller bool、request 全 File、旧 ledger の fabricated certificate を入力にしない。
3. 各 root について `reverse_reached` の path と public File projection の交差を計算し、いずれかが残る場合は internal `reverse_publication_conflict` として locality 不成立に含める。
4. `affected_paths` と `reverse_affected_paths` の既存 projection は変更しない。新しい public field／schema／diagnostic codeを追加しない。
5. `target_tainted` と現行 `open_dependency` predicate は変更しない。特に RG-SI04-02 の forward／reverse open-edge behavior は今回変更しない。
6. Conflict のある parse/read ケースは、full proof、target、record-limit、export ordering を通った後、既存 `CSV-NEXT-SOURCE-003`／`payload_unavailable`／artifact無しへ進める。
7. Source inventory partition 自体は変更しない。`src/global.d.ts` は untainted nonprogram File のままであり、File taint、Module、direct failure、causal edgeを捏造しない。最終 publication gate が available payload を止める。
8. Reverse edge のない independent context controls は従来どおり `partial_safe`／payload available を維持する。

**Affected surfaces**

- `tests/contracts/next_semantic_core_v3_validation.py::derive_post_acquisition_locality_v3`
- `tests/contracts/test_next_semantic_core_v3.py` の Core locality regressions
- 修復証拠を記録する既存 Issue artifact／Plan／Report の薄い progress 記録

**Unaffected surfaces**

- SI-03 source grammar、taint、eligibility、partition validators
- `SourceFailureLedger` 旧 reference implementation
- native `source_graph.py`／`source_acquisition.py`
- source／semantic codecs、schemas、dependencies、v2 KATs、runtime owners
- public API、compatibility identity、migration、security、rollback、recovery、OS support
- selected-cardinality TARGET-only no-payload exceptions
- RG-SI04-02 の P2 behavior

**Ordering and state transitions.** Full semantic proof → target proof → actual record limit → export availability → source locality → entity gate の既存 order を変えない。新しい state、retry、lock、journal、cache、dual path は追加しない。

**Rollback／recovery.** Persistent data、migration、external state はない。Code rollback は locality predicate と対応 test の revert のみだが、その revert は R1 regression test を再び Red にし、親 workflow を BLOCKED に戻す。旧 unsafe behavior を runtime compatibility mode として維持してはならない。

**Structural decision signals.** 次のいずれかが必要になった時点で patch chaining を停止する。

- nonprogram File の taint／disposition規則変更
- fake Module、Module→File、File→Project causal rule
- source graph、seal、codec、public locality shape の変更
- SOURCE-003 以外の新 diagnostic／outcome
- RG-SI04-02 の behavior 変更
- target／record／entity ordering の変更
- public API、data、security、migration、compatibility、rollback、recovery、operation meaning の変更

これらは current bounded correction ではなく、親への stop-and-return 条件である。

# Human decisions and authorization

**Parent authorization source.** Packet は、ユーザーが implementation continuation を許可し、primary agent が unchanged governing authority から一意に決まる in-scope P0/P1 correction を実装できると記録している。Analyst は read-only であり、編集権限を新たに付与しない。attachments-bundle

**Uniquely determined correction.** RG-SI04-01 は既存 authority を変えず、reverse failure closure と public File projection の矛盾時に既存 SOURCE-003 へ閉じる修正として一意に定まる。Product、Policy、Security、requirement、canonical design、public contract、state owner の新決定は不要。

**Not authorized in this response.**

- RG-SI04-02 の P2 availability correction
- 新しい acceptance criterion や P2 repair backlog
- SI-03 partition／taint／source graph の変更
- public schema／diagnostic／compatibility version の変更
- actual TypeScript、process、CLI、publication、SI-05 以降の実装

RG-SI04-02 は material design decision を必ず要するとは限らないが、親の P2 report-only policy により、**別の明示 authorization と first-red evidence** が必要である。

Material requirement、design、scope、public-contract、security、data、migration、compatibility、recovery、operation、risk、responsibility allocation の変更が必要と判明した場合、current authorization は失効し、human decision へ戻す。提案する canonical wording はない。

# Implementation handoff

**Authorization:** RG-SI04-01／R1 のみ authorized。RG-SI04-02／R2 の implementation handoff は authorized されていない。

**Bounded objective.** Same-seal parse/read failure の reverse closure に、owner-closed File partition 後も public File が残る場合、File taintや partition を変更せず locality を不成立とし、既存 SOURCE-003 no-payload branchへ進める。

**Exact verified paths and symbols**

- `tests/contracts/next_semantic_core_v3_validation.py`
  - `derive_post_acquisition_locality_v3`
  - verification ownerとして既存 `validate_semantic_decision_v3` を変更せず通す
- `tests/contracts/test_next_semantic_core_v3.py`
  - 既存 `core_inputs_v3`
  - 既存 `exclude_value_module_with_root_v3`
  - 新規 focused locality test nodes
- Thin progress evidence のみ必要な場合:
  - `spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/issues/iss-00008-generate-nextjs-component-snapshots/plan.md`
  - 同 directory の `report.md`
  - authority meaning は変更しない

**Ordered changes**

1. `parse_file` と `read_file` を parameterize した first-red test を追加する。
2. `src/global.d.ts` の bytes に `import { value } from "./value";` を追加し、actual `SourceAcquisitionSeal` graph に `src/global.d.ts -> src/value.ts` の resolved edgeがあることを確認する。
3. Context File が `roles=["context"]`、taints空、public File projection 内であることを確認する。
4. Baseline product SHA `58864bf...` では、期待する SOURCE-003 に反して `localized=true`／`partial_safe` となり、test が Red になることを記録する。
5. `derive_post_acquisition_locality_v3` に、reverse closure と effective public File paths の交差 predicate を追加する。
6. `localized` の既存判定にその conflict を加える。新しい output key、diagnostic、state は追加しない。
7. 修正後、両 root kind で `localized=false`、`CSV-NEXT-SOURCE-003`、`payload_available=false`、artifact paths空を確認する。
8. 同じ candidate の independent decision validator が rederived result を受理することを確認する。
9. Import を追加しない independent context controls が `partial_safe`／payload available のままであることを確認する。
10. RG-SI04-02 の normal open-edge predicate に差分がないことを diff と negative assertion で確認する。

**Explicit non-goals**

- R2 の修正
- context File の除外、taint、direct failure化
- `.d.ts` 用 fake Module
- graph／seal／request／transport の作り直し
- legacy whole-ledger certificate の呼出し
- target／budget／export ordering の変更
- schema、dependency、runtime、public contract の変更

**Prohibited choices**

- Module→File または File→Project の逆 causal edge
- arbitrary `safe`／`localized` caller bool
- public File を自由に drop する partition
- fabricated candidate、Module、seal、graph
- source acquisition／graph codec の変更
- P2 behavior を P1 patch に便乗して変更すること

これらの禁止境界は packet の実装制約と一致する。attachments-bundle

**First-red evidence.** Red は「現 candidate の product code」と「新 test patch」の組合せに対して取得し、product baseline SHA `58864bf0223e35c6cf31ca09b0d9040954e3d9cc`、test diff identity、実行 node IDs、observed wrong gate/locality を記録する。

**Stop-and-return conditions**

- public File path と graph nodeを既存 identityだけで正確に join できない
- expected independent controls が保持できない
- `derive_post_acquisition_locality_v3` 以外の lower-layer contract change が必要
- source inventory、graph、taint、schema、diagnostic、ordering の変更が必要
- RG-SI04-02 の behavior change が不可避
- exact path／symbol／current assumption が disproved
- API、data、security、migration、compatibility、rollback、recovery、operation impact が発生
- canonical authority 間の contradiction が見つかる

**Evidence return destination and format.** Implementer は parent workflow に一つの Markdown evidence bundleとして、固定 full SHA、変更 path／symbol、R1／RG-SI04-01 mapping、First Red、focused Green、aggregate results、negative assertions、log/artifact pointers、clean worktree／published checkpoint stateを返す。Reviewer session、GitHub issue、workflow stateを implementer が自動更新してはならない。

# Verification plan

## Supplied results

- GitHub target ref exact SHA: `58864bf0223e35c6cf31ca09b0d9040954e3d9cc`
- Review: `review_status=fail`, R1=P1, R2=P2
- Fresh exact-SHA probe: R1 current behavior reproduced for parse_file／read_file
- Independent context controls: current `partial_safe` behavior確認済み
- Existing Core／regression／shared algorithm／schema-golden selections: same-content Green
- Ruff、format、mypy、SpecDock、pointer／diff checks: terminal Green
- R2: code/control path traceのみ、fully Core-valid executionなし

## Future obligations

`FIXED_SHA` は実装完了後の一つの full 40-hex candidate SHA とし、Green、aggregate、review の全結果を同じ `FIXED_SHA` に結ぶ。

**First Red**

- Product baseline: `58864bf0223e35c6cf31ca09b0d9040954e3d9cc`
- New tests: parse_file／read_file reverse nonprogram importer
- Expected Red reason: current code returns `localized=true`／`partial_safe` instead of SOURCE-003
- Current wrong behaviorを期待値として固定する probe ではなく、desired contract assertionとして失敗させる

**Focused Green on `FIXED_SHA`**

- Both root kinds produce SOURCE-003/no payload
- Actual same-seal resolved edge is present
- No open edge、no acquisition failure
- Context File remains untainted and no fake Module exists
- Reverse closure contains context importer
- Independent validator accepts rederived corrected result
- Independent controls remain partial-safe
- Multiple rootsのうち一つでも conflict があれば fail-closed
- Existing selected-cardinality exceptional path is unchanged

**Aggregate regression on `FIXED_SHA`**

- Full `test_next_semantic_core_v3.py`
- Packet に記録された previous five modules selection
- Shared-algorithm selection
- Python／SQLAlchemy goldens and schemas
- Actual record 10000/+1、entity 500/+1 を除外しない
- Ruff check、Ruff format、mypy、SpecDock sync/validate、Current pointer、diff checks

結果数は重複 selection 間で合算しない。

**Integration／runtime evidence on `FIXED_SHA`**

- `DescriptorAnchoredSourceReadSession`
- Actual `SourceAcquisitionSeal`
- Actual source graph derived from source bytes
- Retained assets／request／transport fixtures
- Current public Core factory
- Independent decision validator

Old ledger、fake graph、fake seal、fake candidate、fake Module による代替は禁止。Actual TypeScript／OS process certification はこの unit の obligation ではない。

**Semantic checkpoints**

- Failure closure/public projection conflictだけが新たに nonlocal
- Public File partition と taint fixed point は不変
- `affected_paths`／`reverse_affected_paths` の shape は不変
- `module_plane` behavior は不変
- Normal open-edge behavior は今回不変
- Target、record-limit、export、SOURCE、entity ordering は不変
- No new public fields／diagnostics／versions

**Negative assertions**

- Reverse edgeのない context Fileは availableのまま
- Safe-side B は残る
- Context Fileに taint／direct failureを追加しない
- `.d.ts` Moduleを生成しない
- Source graphやdigestを置換しない
- Legacy ledgerを fabricated seal で呼ばない
- R2 behavior を変更しない

**Rollback verification.** `FIXED_SHA` の patch revert により、新 R1 test が再び Red となり、workflow が BLOCKED に戻ることを確認する。Persistent data／migration rollback は存在しない。Unsafe behavior を互換 mode として残さない。

**Review binding.** Fresh cumulative review は unchanged base `caf38329826ae34f8e3cb330b83b97e0357b7dc5..FIXED_SHA` を対象にし、reviewed SHA と tested SHA を一致させる。

# Same-reviewer re-review obligations

Parent policy 上、source reviewer conversation `6ac03f58-17e8-83e8-b469-0c0b5010d7b6` を再利用しない。Finding closure obligation は元 reviewer の claim に対応付けるが、実 transport は **fresh independent cumulative Code Review Strict conversation** とする。attachments-bundle

| Source／group | Expected status | Fresh reviewer obligation |
|---|---|---|
| `R1` / `RG-SI04-01` | **Expected closure** | parse/read の actual nonprogram reverse importer が SOURCE-003/no payload となり、taint・Module・partitionが捏造されていないことを独立再検証する。 |
| `CG-SI04-01` | **Expected closure** | 新 first-red test、fixed-SHA Green、independent controls、validator rederivation を確認する。 |
| `R2` / `RG-SI04-02` | **Still open / report-only** | P2 classificationを保持して current codeを独立確認する。今回の修復で normal open-edge predicate が変わっていないことを確認する。P2 は pass blocking 条件へ昇格させない。 |
| `CG-SI04-02` | **Still open** | Fully Core-valid compound fixture が未実行であることを uncertainty として保持する。別 task なしに closure や remediation を要求しない。 |

**Disproof.** R1 を disproved とするには、actual seal graph／public File projection／full proof上で reviewer の trigger が到達不能であることを示す必要がある。Local assertion や fake fixture は disproof にならない。既存 exact-SHA probe が trigger を実証しているため、現 candidate についての disproof は成立しない。

**Supersession.** Requirement／Design／admission contract の approved change により source-locality meaning が変わった場合のみ supersession となる。Current response に approved contract change はない。

**Completion sweep.** Fresh reviewer は同じ root cause の adjacent pathsとして、少なくとも次を確認する。

- parse_file／read_file
- nonprogram context importer／program importer
- reverse edgeあり／なし
- single／multiple failure roots
- multi-project safe side
- resolved edge／normal open edge／`module_plane`
- explicit target が forward／reverse closure と交差する場合
- selected-cardinality no-payload exceptions
- independent context control
- source inventory seam と final gate の owner consistency

R1 closure後も R2 は report-onlyのまま残り得る。それだけで re-review fail としてはならない。

# Parent workflow consequence

**Current consequence.** SI-04 certification は blocked。SI-05、production、publication、whole-Issue completion は引き続き blocked。

**Next parent-owned action.** Parent は RG-SI04-01 の bounded implementation を primary implementer に渡せる。修復後、同一 `FIXED_SHA` に対する focused Green、aggregate regression、quality checks、clean/published checkpointを揃える。

**Review prerequisite.** その後、base `caf38329826ae34f8e3cb330b83b97e0357b7dc5` から `FIXED_SHA` までを対象に fresh independent cumulative Code Review Strict を開始する。旧 reviewer conversation は再利用しない。

**Continuation condition.** Required local checksが Green で、fresh review が `P0=0 / P1=0 / review_status=pass` を返した場合に限り、親は SI-04 を認定し SI-05 を開始できる。R2／P2 が残っても、親 policy 上は report-only である。

**Human-decision condition.** 実装が source inventory、taint、graph、public contract、diagnostic、security、data、migration、compatibility、rollback、recovery、operation、risk、responsibility allocation を変える必要がある場合、修復を停止して human decisionへ戻す。RG-SI04-02 を変更する場合も、少なくとも新しい明示 task authorization と first-red evidence が必要。

**Fresh campaign.** Unchanged-authority R1 fixには新 scope identity は不要だが、fresh one-shot review campaign は必須。Canonical meaningを変更する場合は current remediation objectiveを supersedeし、新 decision package／必要に応じ新 campaignを作る。

**Outside this skill.** 編集、test実行、Git操作、push、issue／thread更新、reviewer invocation、workflow transition、SI-04 closure、SI-05開始は parent／implementer／reviewer の責務であり、本 analyst は実行していない。

# Assumptions and unresolved evidence

- Packet 内に reproduced された review JSON、artifact digest、reviewer provenance が完全かつ改変されていないことを前提とする。本 analyst は raw Oracle log の digestを再計算していない。
- Reviewer model／thinking provenanceは UI picker観測であり backend attestationではない。
- 元 aggregate test jobs は same-content evidenceであり、final SHA process-start evidenceではない。修復後の結果へ流用できない。
- R1 probeは exact `58864...` で current wrong behaviorを実証するが、accepted regression testではない。
- R2 の predicate-level mismatch と graph-layer trigger は確認できるが、fully Core-valid compound fixture の end-to-end outcomeは未実証である。
- R2 を current handoffから除外すると、既知の availability regression risk が残る。親 policy によりこれは意図的な report-only residual risk である。
- Fixed implementation が effective public File projection 以外の集合を使用した場合、RG-SI04-01 の correction は無効になる。
- Branch tipが `58864bf0223e35c6cf31ca09b0d9040954e3d9cc` から動いた場合、この packet の current-candidate binding は失効し、分析前に exact GitHub verificationをやり直す必要がある。
- Source graph、partition、taint、diagnostic、ordering、public schemaの変更が発生した場合、unchanged-authority remediation という authorization premise は失効する。
- Actual TypeScript、OS process、CLI、publication、all-contract/full suite の結果は本 packet に存在せず、SI-04 locality disposition以外の certificationへ外挿してはならない。
