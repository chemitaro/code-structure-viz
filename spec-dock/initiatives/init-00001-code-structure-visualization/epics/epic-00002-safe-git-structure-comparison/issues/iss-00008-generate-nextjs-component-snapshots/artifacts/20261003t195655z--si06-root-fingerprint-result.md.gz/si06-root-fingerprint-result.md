## 結論

これは、**既存のCurrent canonical定義だけでは安全に閉じられない、実在するcontract／owner handoff gap**です。

具体的には、Currentのsemantic authorityは、matching admitted transport／Coreが存在しないfailureについて、semantic `run_fingerprint` を意図的に `null` とします。一方、Next rootの `run-manifest-v2` は `run.fingerprint` を必須・nonnull digestとして要求しています。旧Next reference producer／validatorは、domainのsemantic fingerprintをrootへそのままjoinしていますが、その実装はnonnullのcomplete例だけを扱っており、Current v3のCore無しfailureを収容する定義にはなっていません。

また、generic coreに存在する七keyの `run-fingerprint/v1` は利用可能な既存ハッシュ関数ではあるものの、Next semantic十四key fingerprintとは、意味、preimage、owner、consumer joinが異なります。したがって、Core無しfailureだけgeneric fingerprintへ切り替えることを「既存意味の明確化」として導入することはできません。これは新しいroot identity policyであり、人間による明示採択が必要です。

**最推奨は、Currentのsemantic fingerprint規則を変更せず、Next rootに新しいidentity／versionを設け、そのsemantic runtime binding fingerprintをnullableとして表現する案です。**

すなわち：

- matching admitted transport／Coreなし  
  → semantic runtime binding fingerprintは `null`
- matching admitted transport／Coreあり  
  → Core rejectionを含め、Current v3のexact十四keyからnonnull digest
- eligibleなSOURCE／TARGET／EXPORT／entity failure  
  → semantic familyが成立していればnonnull digestを保持
- publication result hash  
  → 上記とは別の結果ハッシュとして維持
- generic source／request fingerprint  
  → 将来必要なら別名・別field・別ownerで新規採択し、semantic fingerprintの代用品にしない

これはCode Review、Spec Review、pass/fail、severity判定、production readiness認定ではありません。また、current checkpointをwhole SI-06 passとは扱いません。

---

## 1. live exact-SHA確認

GitHub connectorで実際に次を確認しました。

| 項目 | 確認結果 |
|---|---|
| repository | `chemitaro/code-structure-viz` |
| target branch | `iss-00008-generate-nextjs-component-snapshots` |
| expected SHA | `fca99a91c11f33de5199e67996be1be671e10298` |
| connector取得branch tip | `fca99a91c11f33de5199e67996be1be671e10298` |
| 比較 | byte-for-byte完全一致 |
| branch tree SHA | `1ded217c71990cfc21d269e47cc4cf0325ea84b0` |
| 他branchの参照 | 未実行 |

実施したconnector operationは次のとおりです。

1. repositoryを直接取得  
2. repository内でtarget branchを検索  
3. GitHub branch APIをtarget branch名で直接取得  
4. 返されたfull tip object IDをexpected SHAと完全比較  
5. 以後の文書・schema・source取得は、このfull commit SHAを `ref` に固定

branch tipは完全一致しています。 

添付の `attachments-bundle.zip` も指定どおり一時ディレクトリへ展開し、22ファイルのtreeを確認しました。そのうち21件はrepository候補、1件はignored Workbenchのsource-excerptsでした。Workbenchは検索案内としてのみ使用し、authorityには使用していません。

主要な添付ファイルについてはGit blob IDを計算し、exact commitのGitHub contents metadataと照合しました。主要contract、schema、accepted ADR、source実装は一致しています。ただし、正本判断は一貫してGitHub connectorで取得したexact commit側に置いています。

---

## 2. 現状と今回の実証範囲

Current R/D/Pでは、今回採択済みの変更範囲はpublication-v2 adapter captureの二fieldに限定されています。

- capture未観測：`stdout = null` かつ `stderr = null`
- capture観測済み：`stdout` と `stderr` はともにobject
- 観測済み0 byte：objectのまま、0として表現
- public diagnostic stderr：実測objectが必須
- selected stdout：実測objectが必須
- 未観測値のzero-fillは禁止
- wire version／URN／outer hash preimage／lower owner／semantic contract／Python／SQLAlchemyは変更しない

Current requirementは、旧object-only consumerがnullを拒否し得ること、schema・producer・validatorを一体で動かす必要があること、旧SI-05 evidenceを新契約のcertificateとして再利用できないことも明記しています。 

Current designも、authorityをCurrent R/D/P、SI-v3 contract、accepted ADRに置き、semantic/run outcomeとpublication outcomeを別の軸として扱っています。 

Current planでは、root fingerprint問題は別discussionに切り出されており、そこで新hash、schema変更、Product変更は採択されていません。SI-06 TDDとunit exit以後のgateも完了していません。 

したがって、今回確認できる実証範囲は次の限定範囲です。

- schema null pair
- artifact-selectorのfailure axes
- 実参照ownerでの64 KiB／16 MiB exactと+1
- resealed native／cache／null／zero
- foreign input
- public privacy
- same candidates-v3をauthority inputとするdiagnostic／final stderr／selected stdout branch

確認できない、または未完了の範囲は次です。

- all selectors
- root owner全体
- summary／manifest／domain root実装
- all-contract suite
- full pytest
- mandatory whole-unit gates
- fresh independent Code Review
- persistent consumer inventory
- production readiness

---

## 3. authority照合表

| 論点 | Current authority | 確認した意味 | 今回の判断 |
|---|---|---|---|
| captureのnull/object | Current R/D/P＋accepted ADR | 未観測ならnull/null、観測済みならobject/object。0 byteもobject | 採択済み。実装権限内 |
| semantic fingerprintのCore無しfailure | `next-run-decision-v2`、v3継承 | admitted transport／Core outcomeがなければnull。PID、path、stderr、failure reason等から合成禁止 | 維持必須 |
| semantic fingerprint preimage | `next-semantic-v3.md` | exact十四key、結果partition/count、process/host/captureを含めない | 維持必須 |
| domain projection | `next-domain-manifest-v2.schema.json` | `run_fingerprint` はrequiredだがdigestまたはnull | Core無しfailureを表現可能 |
| config projection | `next-config-v1.schema.json` | `snapshot_request.run_fingerprint` はoptional digest。nullは値として不可 | Core無し時は原則omit方向だが、正式join規則の明文化が必要 |
| root projection | `run-manifest-v2.schema.json` | `run.fingerprint` はrequired nonnull digest | Current semantic nullと衝突 |
| 旧Next root join | 旧reference producer／validator | root fingerprint＝domain fingerprint。complete nonnull例のみ | historical／reference。Current null branchのauthorityではない |
| generic root fingerprint | `run-manifest-v1.md`＋`manifest.py` | 七keyのrequest/input/config系identity | semantic十四keyとは別契約 |
| root config provenance | `run-manifest-v2.schema.json` | `resolved` と `value_sources` が必須。sourceはcli／repository／builtin | Current retained contextだけでは完全導出不能 |
| publication result hash | final publication owner | publication結果の封印／整合用 | semantic bindingの代用品ではない |
| root-fingerprint discussion artifact | Current exact commitのdiscussion | conflictを記録するがdecision未採択 | 人間判断が必要 |

`next-run-decision-v2` は、semantic fingerprintがattempt／process fingerprintではなく、matching admitted transport／Coreがなければnullでなければならないことを定めています。failure専用hash、fake binding、PID、path、stderr等による補完を禁止しています。 

`next-semantic-v3` のexact十四keyは次です。

1. `fingerprint_version`
2. `artifact_id`
3. `run_id`
4. `kind`
5. `project_root`
6. `manifest_path`
7. `runtime_identity`
8. `compiler_identity`
9. `compiler_options`
10. `entrypoints`
11. `base_url`
12. `path_aliases`
13. `source_policy`
14. `profile`

この十四key以外、特にresult partition、counts、response、process、host observation、capture observationをpreimageへ足すことはできません。 

domain側はnullを正式に許容します。 

config側のsnapshot request fingerprintはoptional digestで、null値ではありません。したがって、semantic bindingが成立しない場合に、fake digestを置く根拠はありません。 

一方、root schemaは `run` 等を必須とし、`run.fingerprint` をdigest-onlyで要求します。さらにroot configにはresolved valueとvalue source provenanceも必要です。  

---

## 4. fingerprint／hashの意味分離

今回の判断で最も重要なのは、次の四つを同一視しないことです。

### 4.1 source-owned input fingerprint

source viewや入力集合を識別するものです。入力sealやsource fingerprintは、何を入力として読んだかを表します。

これは、compiler/runtimeとのsemantic bindingが実際に成立したことを意味しません。

### 4.2 semantic runtime binding fingerprint

Current Next v3のexact十四key fingerprintです。

これは、特定のartifact、run、kind、project root、manifest、runtime、compiler、compiler options、entrypoints、base URL、path aliases、source policy、profileの組を識別します。

matching admitted transport／Coreがない場合は、そのbindingを観測・成立させていないため `null` です。

非nullであっても、成功を意味しません。Core rejectionや、そのsemantic familyに属するvalidated failureでも非nullになり得ます。

### 4.3 generic root/request fingerprint

generic `run-fingerprint/v1` は次の七要素から成る別familyです。

- schema/version
- tool version
- adapter version
- source fingerprint
- config SHA-256
- command
- normalized request

これは入力とrequest/config identityを表すため、Core実行前でも生成しやすい性質があります。しかし、Next semantic十四key fingerprintとは同じ意味ではありません。

### 4.4 publication result hash

最終的に公開されるpublication documentやprojectionの結果を封印・joinするためのhashです。

これは、「どのsemantic runtime bindingで解析したか」でも「どのsource requestを所有したか」でもありません。

そのため、publication hashをroot semantic fingerprintの代わりに使うこともできません。

---

## 5. 根本原因

根本原因は、単純なschema typoではなく、**一つのfieldへ複数identityを重ねたまま、failure branchのowner契約が定義されていないこと**です。

### 5.1 Current semantic ownerはnullを正しく返す

Core無しstage failure／selector failureでは、semantic ownerは十四key bindingの成立を観測していません。

したがって：

```text
semantic_run_fingerprint = null
```

が正しい出力です。

ここにPID、path、capture fields、failure reason、process metadata、stderr、fake Core identityを足してdigestを作ることは、Current contract違反です。

### 5.2 domainとconfigはnull／absenceを表現できる

domainは明示的にnullを許容します。

configのsemantic bindingはoptionalなので、binding不成立時にomitできます。ただし、root／domain／config間のnull branch joinをCurrent canonical proseとして明記する余地は残っています。

### 5.3 rootだけがnonnullを要求する

root `run.fingerprint` は必須digestです。

旧referenceは：

```text
root.run.fingerprint = domain.run_fingerprint
```

というjoinを使いますが、complete成功literalを前提にしたreferenceです。domainがnullの場合のbranchを持っていません。

これをCurrentのCore無しfailureへ適用すると、root schemaが `None` をstring type errorとして拒否します。これは限定probeの観測とも整合します。

ただし、root owner全体が未実装であるため、これを「新root implementationの失敗」とまでは評価できません。正確には、**root ownerを実装する前に露呈したcontract admission gap**です。

### 5.4 generic七keyは自動fallbackにならない

generic fingerprintは存在しますが、次の理由でCurrent Next rootへそのまま適用できません。

- preimageが十四keyと異なる
- semantic runtime bindingではなくrequest/input identity
- producer ownerが異なる
- domain/config/root consumer joinが異なる
- 同じ `run.fingerprint` 名で意味を切り替えると、値だけを見てfamilyを判別できない
- failure branchだけ別preimageにすると、同一fieldがrun状態に応じて別identityになる
- Current R/D/P、accepted ADR、root-fingerprint discussionのいずれもこのfallbackを採択していない

したがって、これは「既存generic関数を再利用しただけ」ではなく、新しいcontract decisionです。

### 5.5 Current retained contextはgeneric root configの完全ownerではない

`RetainedNextAnalysisContextV2` が保持するactual intent、run context、domain config、source seal等から、generic request preimageの一部は作れます。

しかしroot schemaのconfigには、resolved valuesだけでなく、各値が次のどこから来たかというprovenanceが必要です。

- `cli`
- `repository`
- `builtin`

Current retained contextだけからは、すべてのoriginを正当に再構成できません。

次は不適切です。

- 値からoriginを推測する
- defaultに見えるからbuiltinと決める
- golden fixtureのmetadataをactual owner observationとして複写する
- repositoryに同じ値があるからrepository originとみなす

よってgeneric案には、fingerprint定義だけでなく、config provenanceを観測し保持する追加ownerが必要です。これは別の未完了境界です。

---

## 6. 旧reference／historical proseとCurrent canonicalの違い

### 旧Next reference

旧referenceの `_run_manifest` とvalidatorは、domain semantic fingerprintをrootとconfigへ投影し、三者の一致を検証します。

このreferenceが証明するのは、主に次です。

- completeなnonnull fixtureのschema composition
- nonnull semantic fingerprintのcross-document join
- fixture由来config provenanceのschema適合
- SI-05 outer literalの整合

証明しないものは次です。

- Core無しCurrent v3 failure
- nullable semantic bindingを含むroot owner
- Current candidates-v3からの実owner derivation
- runtime failureのmanifest policy
- persistent consumer compatibility
- root identity familyの選択

したがって、旧referenceをCurrent null branchのauthorityとして用いることはできません。

### historical prose

後半Roundのhistorical proseや旧certificateは、当時のcontractとfixtureに対するevidenceです。

Current R/D/Pとaccepted ADRが後からcapture observation semanticsを修正している以上、旧passをCurrentのcertificateに繰り上げることはできません。

### generic core implementation

generic coreは実際に稼働する別のroot/request identity contractです。

「実装済みだからNextにも適用可能」ということにはなりません。適用には少なくとも次が必要です。

- field名と意味の採択
- Next producer ownerの指定
- exact preimageの採択
- config provenance ownerの指定
- domain／config／root joinの再定義
- schema／URN／version policy
- consumer migration
- negative vectors

---

## 7. 選択肢比較

| 選択肢 | 長所 | 主な問題 | 判断 |
|---|---|---|---|
| A. `run-manifest-v2.run.fingerprint` をin-place nullable化 | 最小のschema／producer変更 | 既存v2 consumerのnonnull前提を静かに破る。field意味とversionが同じまま変わる | 条件付き代替 |
| B. 全Next rootをgeneric request fingerprintへ変更 | Core無しでも安定したnonnull identityを持てる | semantic十四keyとのjoinが消える。owner／provenance未完了。明示仕様改訂が必要 | 今回は非推奨 |
| C. Core無しfailureではmanifestを抑止 | schema conflictを回避 | typed failure publicationを失うProduct変更。Coreなしを省略する処置は要件上不可 | 却下 |
| D. failure専用hashを新設し同じfieldへ入れる | nonnull制約を満たせる | fake binding。状態依存でpreimage familyが変わる。semantic contract違反 | 却下 |
| E. 新しいNext root identity／versionでsemantic fingerprintをnullable化 | 意味が明確。旧consumerを保護。version routingでrollback可能 | 新schema／URN／reader／migrationが必要 | **最推奨** |
| F. 新versionでrequest fingerprintとsemantic fingerprintを分離 | 長期的に最も明確 | 新request owner、provenance、preimageの採択が必要。SI-06最小修正を超える | 将来案 |

---

## 8. 最推奨案

### 8.1 推奨するcontract shape

新しいNext root identity／versionで、少なくとも次の意味を明示します。

```text
semantic_run_fingerprint:
    digest | null
```

意味：

- `null`
  - matching admitted transport／Coreがない
  - semantic runtime bindingを観測・成立させていない
- digest
  - exact十四keyのCurrent v3 semantic familyが成立
  - 成功を意味しない
  - Core rejectionやeligible validated failureを含み得る

可能ならfield名自体も `semantic_run_fingerprint` のように意味を明示した方が安全です。ただしrenameはconsumer migrationが大きいため、新version内で旧名を維持するか、新名に分離するかは人間判断です。

### 8.2 正常branch

matching admitted transport／Coreがある場合：

1. same current contextからexact十四keyを取得
2. canonical encodingでsemantic digestを計算
3. domainへ同digest
4. config snapshot requestへ同digest
5. root semantic bindingへ同digest
6. validatorがすべての一致を検証

Core rejectionであっても、matching transport／Coreが存在するならnonnullです。

### 8.3 null branch

matching admitted transport／Coreがない場合：

1. semantic ownerは `null`
2. domainは `run_fingerprint: null`
3. configのoptional semantic bindingはomit
4. rootのsemantic bindingは `null`
5. validatorは三者を次のようにjoinする

```text
domain == null
config semantic binding absent
root semantic binding == null
context/core eligibility == false
```

ここにgeneric digest、publication hash、PID、path、capture metadata、failure reasonを代入してはいけません。

### 8.4 将来のrequest identity

Core以前のfailureでもnonnull root identityがProduct上必要なら、semantic fingerprintとは別に、たとえば：

```text
request_fingerprint: digest
semantic_run_fingerprint: digest | null
publication_result_hash: digest
```

と分離するのが正攻法です。

ただし `request_fingerprint` の採択には以下が必要です。

- source-owned input identity
- normalized request
- effective config
- exact config provenance
- owner lifetime
- canonical serialization
- version
- consumer meaning

generic v1を参考にすることはできますが、自動継承はできません。

---

## 9. なぜ新versionを推奨するか

### 9.1 nullable化自体は意味的に自然

semantic fingerprintのnullは、Current domainですでに正式な意味を持っています。

したがって、rootがsemantic bindingを投影するならnullableであることは自然です。

### 9.2 しかしv2を静かに変えるのは危険

root v2は現在nonnullをschemaで約束しています。

そのためin-place nullable化は、schema変更量は小さくても、persistent consumerに対しては大きな変更です。

想定される影響：

- DB columnのNOT NULL
- index key
- cache key
- object store path
- analytics join
- readerのstring method呼び出し
- deduplication key
- manifest comparison
- external JSON schema validation

consumer inventoryが未完了な状態でv2を静かに広げると、producer側ではvalidでも下流が壊れます。

### 9.3 new versionならrollback可能

新version／URNであれば：

- old producer／readerはv2を維持
- new producer／readerだけnullable branchを扱う
- rolloutをversion routingできる
- rollback時にold formatへ戻せる
- old artifactを再解釈しない
- fake backfillが不要

### 9.4 identity collisionを防げる

同じ `run.fingerprint` fieldへ、成功時はsemantic十四key、failure時はgeneric七keyを入れる方式では、digest stringだけからfamilyを識別できません。

new versionで明示的なfield semanticsを与えれば、このcollisionを避けられます。

---

## 10. 必要な最小変更

### 10.1 Requirement

追加すべき内容：

- root fingerprintはsemantic runtime bindingのprojectionであること
- Core eligibilityによるnull／nonnull branch
- Core rejectionはnonnullであること
- eligible SOURCE／TARGET／EXPORT／entity failureはnonnullを保持できること
- nullは失敗一般ではなく、binding未成立を意味すること
- root fingerprintは成功証明ではないこと
- request/input/result hashとは別identityであること
- old root versionのconsumer compatibility policy

### 10.2 Design

明記すべきowner：

| 値 | owner |
|---|---|
| source input fingerprint | source-view／seal owner |
| semantic run fingerprint | admitted transport＋Core context owner |
| config provenance | config-resolution owner |
| root projection | root manifest owner |
| publication result hash | final publication owner |

加えて：

- exact十四key preimage
- null eligibility predicate
- config optional bindingとのjoin
- version／URN routing
- rollback path
- persistent consumer migration

### 10.3 Plan

TDD順序は次が適切です。

1. root null branchのschema negative testを先に追加
2. semantic eligibility matrix
3. new root schema／version
4. root producer
5. cross-document validator
6. old reader compatibility
7. persistent consumer inventory
8. migration tests
9. whole contract suite
10. full pytest
11. mandatory unit gates
12. fresh independent Code Review

### 10.4 Schema

推奨：

- new root schema／version
- root semantic fingerprintをdigestまたはnull
- config semantic bindingは、nonnull branchでrequired、null branchでabsent
- conditional schemaだけに依存せず、cross-document validatorでもowner eligibilityを確認

in-place v2 nullable化を採用する場合は、少なくともconsumer inventoryとatomic migrationを先にgateにする必要があります。

### 10.5 Producer

root producerは、同じCurrent retained contextからsemantic eligibilityを判断します。

禁止：

- `domain.run_fingerprint or generic_fingerprint`
- `domain.run_fingerprint or publication_hash`
- `null` をzero digestへ変換
- failure fieldsをhash
- fixture／goldenのconfig provenanceを転記
- missing originをbuiltinと推測

### 10.6 Validator

validatorは単なるschema validationでは不十分です。

少なくとも次を再導出・検証します。

```text
Coreなし:
    domain.run_fingerprint is null
    config.snapshot_request.run_fingerprint is absent
    root.semantic_run_fingerprint is null

Coreあり:
    exact十四keyをcontextから再導出
    domain == config == root == rederived digest
```

さらにpublication hashは別field／別validator pathで扱います。

---

## 11. 必須negative vectors

最低限、次を追加すべきです。

1. **Core無し＋任意digest**
   - semantic fieldにdigestを置いたmanifestを拒否

2. **Core無し＋generic七keydigest**
   - generic digestをsemantic fieldへ代入したmanifestを拒否

3. **Coreあり＋null**
   - matching admitted transport／Coreがあるのにnullなら拒否

4. **Core rejection＋null**
   - rejectionはmatching Coreがあるので拒否

5. **domain／config／root不一致**
   - いずれか一つだけ異なるdigestを拒否

6. **semantic preimageへのresult追加**
   - result partition／countsを変えてもsemantic digestが変わらないこと

7. **process observation追加**
   - PID、path、host、timeout timing、capture size等でsemantic digestが変わらないこと

8. **capture stateとsemantic stateの混同**
   - null/null captureでもCoreありならsemantic digestはnonnullになり得る
   - object/object captureでもCoreなしならsemantic fingerprintを合成しない

9. **観測済みzero capture**
   - stdout／stderrはobject/object、byte count 0
   - nullへ縮退しない

10. **config origin推測**
    - owner observationのない`cli`／`repository`／`builtin`を拒否

11. **golden metadata流用**
    - fixture originをactual runtime originとして使うproducerを拒否

12. **publication hash代用**
    - publication result hashをsemantic fingerprintへ置いたdocumentを拒否

13. **old-version compatibility**
    - old readerがnew versionを誤ってv2として解釈しない

14. **exact／+1 budgets**
    - 現在の64 KiB／16 MiB exactと+1を維持

15. **reseal／foreign／privacy**
    - current focused gatesをroot変更後も再実行

---

## 12. 移行、rollback、persistent consumerへの影響

### 12.1 migration

調査対象：

- JSON schema consumers
- DB columns
- cache／dedup keys
- artifact paths
- indexes
- analytics pipelines
- manifest comparison tools
- downstream validators
- external readers
- CI fixtures
- long-lived stored artifacts

nullableを扱えないconsumerには、version-aware readerが必要です。

### 12.2 stored artifact

過去artifactを新意味で再解釈してはいけません。

- old v2 nonnull fingerprintはold contractのまま
- new versionのnullはbinding未成立
- 過去Core無しfailureへfake digestをbackfillしない
- generic digestを再計算して埋めない

### 12.3 rollback

rollbackはversion routingで行います。

- new writer停止
- new readerは残して既存new artifactを読める状態を維持
- old writerへ戻す
- new artifactをold v2へ変換しない
- nullをdummy digestへ変換しない

---

## 13. 実装権限と人間判断の境界

### 現在の採択済み実装権限内

- publication-v2 capture二field
- null/nullまたはobject/object
- observed zeroをobjectとして保持
- same candidates-v3からのprojection
- diagnostic stderrのmeasured object
- selected stdoutのmeasured object
- artifact-selector typed unavailable
- catalog stderr
- current privacy／budget／reseal／foreign-input behavior
-既存semantic null規則の維持
- 未採択root変更をguardしたままにすること

### 人間の明示採択が必要

- root fingerprintをnullableにする
- `run-manifest-v2` をin-place変更する
- new root version／URNを作る
- root fingerprintをgeneric request identityへ変更する
- request fingerprintとsemantic fingerprintを別field化する
- Core無しでmanifestを抑止するProduct変更
- generic config provenance ownerを新設する
- persistent consumer joinを変える
- old artifact migration／backfill policy
- publication hashまたはsource hashをroot identityへ利用する
- root identityの新preimage

したがって、current implementation authorityの範囲でできる正しい処置は、**root ownerを推測で完成させず、明示decision gateを置くこと**です。

---

## 14. 受け入れ条件

推奨案を受け入れるには、少なくとも次が必要です。

### Contract acceptance

- root identity version／URNが明示
- semantic fingerprintのfield意味が明示
- null eligibilityが明示
- exact十四keyが唯一のnonnull semantic preimage
- request/input/result identityとの分離が明示
- success証明ではないことが明示

### Owner acceptance

- semantic ownerがmatching admitted transport／Core contextに固定
- root producerがsame contextのみを利用
- config provenance ownerが明示
- fixture metadataをruntime observationとして使用しない

### Consumer acceptance

- persistent consumer inventory完了
- new version reader実装
- null-safe storage／indexing
- old version isolation
- migration／rollback手順

### Evidence acceptance

- schema tests
- producer tests
- cross-document validator tests
- negative vectors
- focused capture／budget／privacy gates
- all-contract tests
- full pytest
- mandatory whole-unit gates
- fresh independent Code Review

これらが揃うまでは、whole SI-06 passやproduction readinessを意味しません。

---

## 15. 残る未確認点

今回のexact-commit照合から、次はなお未確認です。

1. **persistent consumer inventory**
   - repository外consumerを含め、nonnull前提の全利用者は未確認

2. **new root owner全体**
   - summary／manifest／domain／rootのCurrent runtime producerは未実装またはguard中

3. **generic config provenanceの実owner**
   - Current retained context以外に、CLI／repository／builtin originを保持する正式ownerが存在するかは未確認
   - 存在しないと断定はしないが、今回確認したCurrent root pathからは導出できない

4. **new identity／versionの採択**
   - まだdecisionされていない

5. **full validation**
   - all selectors、all-contract、full pytest、whole unit gatesは未完了

6. **fresh independent Code Review**
   - 未完了

7. **raw compressed Implementation Briefの全文再読**
   - exact commit上のadoption record、Current R/D/P、および採択範囲は確認した
   - raw Briefはcompressed binary artifactで、connectorの通常text fetchでは本文を直接renderできなかった
   - したがって§23／§40については、採択記録とCurrent canonical文書が保証する範囲を越えて、未確認の文言を補完していない

この最後の点によって主結論は変わりません。Current exact-commitのR/D/P、accepted ADR、semantic contract、domain/config/root schemas、旧reference producer／validator、generic implementationの間だけで、semantic nullとroot nonnullの衝突、およびgeneric fallbackが未採択であることは確認できます。

---

## 最終判断

**既存Current canonical定義だけで安全に閉じることはできません。**

既存意味として確定しているのは：

- semantic fingerprintはexact十四key
- Core無しならnull
- failure専用hashで補完しない
- Core rejectionやeligible semantic failureはnonnullになり得る
- capture observationとsemantic bindingは別軸
- generic七keyは別identity
- publication result hashも別identity

未定義なのは：

- semantic nullをNext rootでどう表現するか
- root identityをsemantic bindingのままnullable化するか
- request identityを別途導入するか
- schema／version／URN／consumer migrationをどう扱うか

したがって、最小かつ安全な次の人間decisionは、**新しいNext root versionでsemantic runtime bindingをnullableとして正式化すること**です。そのdecision前にgeneric hashをfallbackとして実装したり、nullをdummy digestへ変換したり、manifestを抑止したりするべきではありません。
