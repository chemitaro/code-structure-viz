添付 `brief.md` の「verified commit のコード・仕様へ grounding すること」「concrete work targets と observable completion evidence を示すこと」「authority 変更が必要なら ready brief と分離すること」に従って整理しています。brief

# Issue #8 SI-06 改訂 Implementation Brief

## 1. Unit / outcome

対象は Issue #8 の **SI-06 のみ**です。

実装対象は、既に採択済みの次の三点を reference implementation / TDD へ具体化することです。

1. 現行 `next-publication-decision-v2` の `measurements.adapter_stdout` / `adapter_stderr` を、同じ capture owner に基づく **nullable pair** へ限定訂正する。
2. `next-run-decision-v3` の actual owner から catalog-owned public diagnostics と final public stderr を導出する。
3. `RetainedRequestBoundPublicationCandidatesV3` を入力 authority とする **single immutable final publication owner** を追加し、semantic outcome と publication outcome を独立に閉じる。

これは製品要件・公開意味・security/privacy policy を新しく決める unit ではありません。

実装後も production Next adapter、actual CLI integration、OS/process acceptance、package/wheel/sdist、reader-owned prefix、ASSET policy、SI-07/08、全 A02/A03、Final Quality Gate は未認定のままです。

---

## 2. Verified repository state

GitHub connector で次を直接確認済みです。

- repository: `chemitaro/code-structure-viz`
- target branch: `iss-00008-generate-nextjs-component-snapshots`
- expected SHA: `c0a1dd2a35326f1656d87ea9a0b907f45a8b123f`
- observed branch tip SHA: `c0a1dd2a35326f1656d87ea9a0b907f45a8b123f`
- SHA comparison: **exact match**

実際に試行した connector 操作は次の三つです。

- repository の直接取得: 成功
- exact branch 名の検索: 成功
- branch 名から tip commit の取得: 成功し、full SHA が expected SHA と完全一致

以後の repository 読み取りは branch 名ではなく full SHA `c0a1dd2a35326f1656d87ea9a0b907f45a8b123f` に固定しました。

repository root の `AGENTS.md` は同 SHA で直接取得を試みましたが GitHub API 404 で、存在を確認できませんでした。

`spec-dock/AGENTS.md`、`spec-dock/SKILL.md`、`spec-dock/README.md` も同 SHA で取得を試み、いずれも 404 でした。

したがって、この brief で適用できる repository-local `AGENTS.md` / SpecDock skill instruction は確認できていません。

`spec-dock/scripts/spec-dock` 自体は確認し、repository を汚さない thin runtime entrypoint であることを確認しています。

この authoring conversation では pytest、mypy、ruff、SpecDock、CI、Code Review Strict は実行していません。

---

## 3. Fixed lineage

SI-06 の累積 review base は次から動かしません。

`af6f5d33f9487a33dabf2ddfe41df85b3d8267fb`

現在の implementation starting checkpoint は次です。

`c0a1dd2a35326f1656d87ea9a0b907f45a8b123f`

採択済み capture correction の Spec Review checkpoint は次です。

`26d3ce1e9f68a25ca60e0f55827bd539d952e56f`

`26d3ce1...` の Spec Review Strict は `review_status=pass`、findings 0 と記録されています。

ただし、その review は physical publication schema、final owner、SI-06 tests を認定していません。

reviewer が tests を実行した証拠でもありません。

backend model identity も attested ではありません。

現在 SHA が source/schema/tests/dependencies を `26d3ce1...` から変更していないという lineage は supplied evidence にありますが、この authoring conversation では両 tree の機械的 full diff は実行していません。

一方、current physical files を直接確認した結果として、

- `next-publication-decision-v2` はまだ capture 二 field を object 必須としている
- bounded target の新規七ファイルはまだ存在しない

ことは verified commit で確認済みです。

---

## 4. Authority order

実装判断は次の順で行います。

1. `requirement.md` の Current normative authority / SI-06
2. `design.md` の Current normative authority / SI-06
3. `plan.md` の Current normative authority / SI-06
4. accepted ADR:
   - `20261002t001435z-adr-issue8-source-inventory-safe-subset.md`
   - `20261002t041350z-adr-issue8-owner-closed-file-module-publication.md`
   - `20261003t142223z-adr-si06-capture-observation-current-v2.md`
5. contract:
   - `docs/contracts/next-semantic-admission-v3.md`
   - `docs/contracts/next-semantic-v3.md`
   - `docs/contracts/next-compatibility-v3.md`
6. `CONTEXT.md`
7. verified current schemas/reference implementations/tests

`report.md` と `20261003t145358z-01-disc-si06-capture-spec-review-pass.md` は evidence であり、新しい authority にはしません。

`Round N` / historical prose を Current authority へ昇格させません。

---

## 5. Governing semantic invariants

`CONTEXT.md` の区別を維持します。

- acquired inventory は一回の observation で取得した完全な Project/File inventory
- safe semantic subset は独立に安全と証明された公開集合
- proof-only record は scope / exclusion の証明用であり public record ではない
- partial-safe は complete-empty や prefix-success ではない

source inventory と safe subset を final publication 層で再解釈しません。

owner-closed File/Module publication を SI-06 で変更しません。

proof-only path、source bytes、raw child stderr、control payload、PID、host-local path を public diagnostic/publication へ流出させません。

---

## 6. Accepted capture correction

`measurements.adapter_stdout` と `measurements.adapter_stderr` の有効な状態は二つだけです。

| candidates-v3 の actual capture | publication-v2 measurement |
| --- | --- |
| capture 未観測 | `null / null` |
| capture 観測済み | `object / object` |

観測済み object は既存 shape のままです。

- `allowed`
- `measured_bytes`
- `retained_bytes`

`0` は観測済みの実測値です。

`null` は未観測です。

この二つを相互変換してはいけません。

次は禁止です。

- `null / object`
- `object / null`
- capture 未観測を zero-fill して object/object にする
- observed zero を null にする
- capture を finalizer で再取得する
- free count / free `allowed` を caller から受ける
- equal-value foreign owner を受ける
- cached metadata の再hashだけで actual owner check を迂回する
- `int()` 等で float/bool を整数へ coercion する

`public_stderr` と `selected_stdout` は nullable にしません。

---

## 7. Publication outcome は semantic outcome と独立

final owner は次の matrix をそのまま実装します。

| source state | final publication |
| --- | --- |
| validated Core complete / partial-safe、public boundary 成功 | `published`; semantic exit に従い 0 または 3 |
| validated Core SOURCE-003 / TARGET / EXPORT / entity-budget unavailable、public boundary 成功 | `published`, exit 3, eligible response link 保持, semantic artifacts 空 |
| rejected Core、public boundary 成功 | `published`, exit 3, response `null`, artifacts 空 |
| runtime-only failure、public boundary 成功 | `published`, exit 3, response `null`, artifacts 空 |
| actual adapter capture overflow | `payload_unavailable`, exit 3, response `null`, artifacts 空 |
| final public stderr overflow | `payload_unavailable`, exit 3, response `null`, artifacts 空 |
| selected-copy overflow、final stderr 成功 | `selected_artifact_unavailable`, exit 3, original semantic status 保持, eligible response link と candidate descriptor 保持 |

capture が未観測であることだけを capture overflow に変換しません。

selected-copy failure の後で final stderr が overflow した場合は `payload_unavailable` が優先します。

---

## 8. Explicit exclusions

この unit では次を変更しません。

- `tests/contracts/next_runtime_v2_reference.py`
- `tests/contracts/next_runtime_v2_validation.py`
- Core-v3 ownership / proof / locality semantics
- run-v3 semantics
- candidates-v3 semantics
- source inventory semantics
- File/Module owner-closed semantics
- compatibility ten-key identity
- fourteen-key run fingerprint
- semantic/public v3 schema meaning
- old runtime/admission/public leaf schemas
- old KAT / golden bytes
- Python behavior
- SQLAlchemy behavior
- `src/**`
- `pyproject.toml`
- `uv.lock`
- dependency set
- production adapter/resource/package
- ASSET policy
- reader prefix
- actual OS/process/TypeScript/CLI
- SI-07 / SI-08

下位 guard を弱めて fixture を通してはいけません。

---

## 9. Confirmed existing owner chain

### Runtime

`tests/contracts/next_runtime_v2_reference.py`

確認済み API:

- `RetainedRuntimeResultV2`
- `reference_process_observation_v2`
- `retain_response_frame_v2`
- `inspect_response_frame_v2`
- `retain_runtime_result_v2`

`RetainedRuntimeResultV2.observation()` が actual retained process observation を返します。

`response_descriptor()` は observed response receipt descriptor だけを返します。

`transport_candidate()` は transport payload が admitted された場合だけ存在します。

final SI-06 code はここを cast、re-capture、再decode しません。

### Core

`tests/contracts/next_semantic_core_v3_reference.py`

確認済み API:

- `ValidatedSemanticDecisionV3`
- `RejectedSemanticDecisionV3`
- `decide_semantic_candidate_v3`
- `inspect_semantic_candidate_v3`

validated Core は same runtime transport candidate / seal / assets へ nominal owner identity で結合されています。

### Run

`tests/contracts/next_run_decision_v3_reference.py`

確認済み API:

- `RetainedRequestBoundRunDecisionV3`
- `retain_request_bound_run_decision_v3`
- `project_request_bound_run_decision_v3`

owner methods:

- `runtime_result()`
- `semantic_decision()`
- `record()`

### Publication candidates

`tests/contracts/next_publication_candidates_v3_reference.py`

確認済み API:

- `RetainedRequestBoundPublicationCandidatesV3`
- `retain_request_bound_publication_candidates_v3`
- `project_request_bound_publication_candidates_v3`

owner methods:

- `run_decision()`
- `artifacts()`
- `record()`
- `artifact_bytes(format_name)`

`capture_measurements.adapter_stdout` / `adapter_stderr` は現在すでに、

- runtime capture が `None` なら両方 `None`
- capture が存在すれば両方 object

として保持されます。

したがって lower-owner correction は不要です。

### Public artifact owner

`tests/contracts/next_public_artifact_v3_reference.py`

確認済み API:

- `RetainedPublicSemanticArtifactV3`
- `retain_public_semantic_artifact_v3`
- `RetainedPublicPlantumlArtifactV3`
- `retain_public_plantuml_artifact_v3`

descriptor は actual immutable bytes から size/hash を計算します。

final owner は caller-supplied artifact descriptor を受けません。

---

## 10. Reusable algorithms, not reusable legacy owners

`tests/contracts/next_reference_validation.py` には以下の wire-independent algorithm が存在します。

- `canonical_json_bytes`
- `digest`
- catalog lookup / diagnostic metadata validation
- canonical diagnostic JSONL encoding
- inclusive byte-limit semantics
- all-or-none public stderr semantics
- selected stdout byte gate
- artifact descriptor size/hash derivation
- typed unavailable resultの既存意味

また legacy implementation には次の concepts が存在します。

- `PublicationBoundaryDecision`
- `finalize_publication_decision`
- `_materialize_publication_boundary`
- `publication_boundary_seal`

これらの **owner/finalizer 自体を v3 run/candidates へ cast して使用してはいけません**。

再利用するのは canonical codec、hash、catalog metadata、inclusive boundary、all-or-none write、pre-copy measurement といった version-independent algorithm だけです。

---

## 11. New bounded paths

verified commit では以下の七 path はすべて不存在です。

実装で追加する対象です。

- `tests/contracts/next_public_diagnostic_v3_reference.py`
- `tests/contracts/next_public_diagnostic_v3_validation.py`
- `tests/contracts/test_next_public_diagnostic_v3.py`
- `tests/contracts/next_final_publication_v2_reference.py`
- `tests/contracts/next_final_publication_v2_validation.py`
- `tests/contracts/next_final_publication_v2_fixtures.py`
- `tests/contracts/test_next_final_publication_v2.py`

加えて、限定変更対象は次です。

- `schemas/next-publication-decision-v2.schema.json`
- capture pair に直接必要な schema regression vectors
- final v2 schema / outer exact-ref に直接必要な regression tests

他 schema の意味変更は行いません。

---

## 12. Proposed internal API

以下は **current code に存在しない提案 API** です。

public API や product API の決定ではなく、この reference unit 内部の最小 seam とします。

### `next_public_diagnostic_v3_reference.py`

```python
def derive_public_diagnostics_v3(
    run_decision: RetainedRequestBoundRunDecisionV3,
) -> tuple[dict[str, Any], ...]:
    ...
```

free diagnostic list は受けません。

同じ run owner / Core / runtime / catalog だけから導出します。

### `next_public_diagnostic_v3_validation.py`

```python
def validate_public_diagnostics_v3(
    diagnostics: tuple[dict[str, Any], ...],
    run_decision: RetainedRequestBoundRunDecisionV3,
) -> None:
    ...
```

validator は `derive_public_diagnostics_v3()` を expected-value builder として呼びません。

actual run/Core/runtime/catalog から独立に再導出・照合します。

### `next_final_publication_v2_reference.py`

```python
class RetainedFinalPublicationV2:
    ...

def retain_final_publication_v2(
    candidates: RetainedRequestBoundPublicationCandidatesV3,
) -> RetainedFinalPublicationV2:
    ...

def project_final_publication_v2(
    owner: RetainedFinalPublicationV2,
) -> dict[str, Any]:
    ...
```

factory の authority input は `RetainedRequestBoundPublicationCandidatesV3` 一つだけにします。

caller から以下を受けません。

- diagnostics
- status / outcome
- response metadata
- artifact bytes
- descriptors
- capture values
- byte counts
- limit override
- selected stdout bytes
- stderr bytes
- seal/hash

### `next_final_publication_v2_validation.py`

```python
def validate_final_publication_v2(
    value: dict[str, Any],
    owner: RetainedFinalPublicationV2,
    *,
    candidates: RetainedRequestBoundPublicationCandidatesV3,
) -> None:
    ...
```

record cache と同値であることだけを証明にしません。

actual candidates owner、run owner、Core/runtime owner、actual retained bytes から再導出します。

---

## 13. First vertical TDD: physical capture-pair correction

最初の Red は final owner implementation より先に行います。

### Fixture

`next_final_publication_v2_fixtures.py` に actual stage-failure candidates fixture を作ります。

提案名:

```python
stage_failed_candidates_v3(tmp_path)
```

構築は `tests/contracts/test_next_run_decision_v3.py` の既存 `stage_failed` route と同じ正規 chain を使用します。

1. `core_inputs_v3`
2. current request / policy
3. `complete_evidence(policy)`
4. `spawn = None`
5. `capture = None`
6. `response = None`
7. `exit_code = None`
8. `terminal_cause = "stage_failed"`
9. cleanup は `not_required`
10. `reference_process_observation_v2`
11. `retain_runtime_result_v2`
12. `retain_request_bound_run_decision_v3(..., semantic_decision=None)`
13. `retain_request_bound_publication_candidates_v3`

fake Core、fake capture、synthetic zero measurement は使用しません。

### Intended Red

actual candidates が次を保持していることを先に assert します。

```text
capture_measurements.adapter_stdout == null
capture_measurements.adapter_stderr == null
```

その owner を使った publication-v2 schema vector について、

```text
measurements.adapter_stdout == null
measurements.adapter_stderr == null
```

を valid と期待する test を追加します。

schema edit 前には current physical schema が両 field を `$defs/measurement` object に固定しているため、その test が失敗することを確認します。

これは意図した Red です。

この時点では「schema shape だけ」の test であり、final owner の証明とは表現しません。

---

## 14. Minimal schema Green

`schemas/next-publication-decision-v2.schema.json` の `$defs.measurements` だけを限定修正します。

`adapter_stdout` と `adapter_stderr` はそれぞれ measurement または null を許可します。

その上で pair constraint を追加し、有効組を次の二つだけにします。

```text
null   / null
object / object
```

実装方法は `oneOf` 等で構いませんが、片側 null が structural に通らないことを schema 自体で証明します。

変更しないもの:

- `$id`
- root `schema`
- `version`
- root required keys
- `semantic_decision` exact ref
- `candidates` exact ref
- measurement object shape
- `public_stderr`
- `selected_stdout`
- response/artifact/stdout/stderr/seal shape
- publication outcome enum

直後に以下を Green にします。

- null/null accepts
- object/object existing vector accepts
- null/object rejects
- object/null rejects
- `public_stderr=null` rejects
- `selected_stdout=null` rejects

既存 SI-05 `outer_vectors` の object/object case は変更せず pass させます。

---

## 15. Second vertical: public diagnostic derivation

次に final owner をまだ広げず、diagnostic seam 一 behavior ずつ閉じます。

### Runtime-only failure

最初は `stage_failed` を使用します。

expected code:

`CSV-NEXT-NODE-002`

catalog metadata は `schemas/next-diagnostic-catalog-v1.json` が authority です。

message:

`The Next.js adapter process could not be started.`

ref permission は `none` です。

path/symbol は両方 null です。

### Independent known literal

NODE-002 一件の canonical JSONL は、producer を使わない independent codec で次を oracle にできます。

```json
{"code":"CSV-NEXT-NODE-002","domain":"next","line":null,"message":"The Next.js adapter process could not be started.","outcome":"payload_unavailable","path":null,"recoverable":false,"ref_permission":"none","schema":"code-structure-viz.diagnostic/v1","severity":"error","symbol":null,"type":"diagnostic"}
```

末尾 LF を一つ加えた UTF-8 長は 304 bytes です。

その independent SHA-256 は:

`ad6bbccccd3625a88f2b4f0f00bcb9dd3597296198c28fe785a6fcd5171b8a9d`

oracle の生成には `derive_public_diagnostics_v3()` を使用しません。

---

## 16. Diagnostic branches

runtime-only Green の後、次を一 branch ずつ追加します。

### Rejected Core

`RejectedSemanticDecisionV3.failure()` の validated failure classification を使用します。

response を public diagnostic の ref source にしません。

raw response bytes を公開しません。

### TARGET

validated target proof から target failure を導出します。

public row は catalog が許可した target path / reason だけを持ちます。

proof 全体を public へ投影しません。

### EXPORT

validated export witness の owner Module identity から catalog-permitted symbol だけを投影します。

raw syntax witness、source span、proof bytes は公開しません。

### SOURCE-003

validated parse/read `failure_roots` と retained source owner の結合から、catalog が許可する failure-root path だけを診断へ出します。

`affected_paths`、reverse closure、proof-only inventory 全体を診断列挙しません。

これにより、

- acquired Project inventory
- public safe subset
- excluded/proof-only rows
- public source-failure diagnostic

を混同しません。

### Entity budget

`CSV-NEXT-LIMIT-005` は catalog の `ref_permission=none` に従います。

budget count を diagnostic message へ埋め込みません。

---

## 17. Diagnostic validator requirements

validator は最低限、次を actual owner から独立に確認します。

- exact `diagnostic-v1` schema
- catalog に code が存在する
- severity exact
- recoverable exact
- message exact
- outcome exact
- ref_permission exact
- path/symbol の許可形
- target reason の closed enum
- canonical ordering
- duplicate aggregate key 不在
- run/Core failure code と一致
- path/symbol が same Core/source owner の検証済み evidence に由来
- foreign equal-content run を拒否
- cached diagnostic row の再hashによる置換を拒否

`decision_public_diagnostics()` を legacy owner ごと呼び出して v3 を cast しません。

---

## 18. Third vertical: base final owner

diagnostic seam の Green 後に `RetainedFinalPublicationV2` を追加します。

最初の success case は ordinary validated complete Core にします。

factory は必ず最初に candidates-v3 independent validation を通します。

owner relation:

```text
RetainedRuntimeResultV2
  -> RetainedRequestBoundRunDecisionV3
  -> RetainedRequestBoundPublicationCandidatesV3
  -> RetainedFinalPublicationV2
```

final owner はこの chain を逆算可能なまま保持します。

---

## 19. Capture projection inside final owner

adapter measurement は candidates owner の actual capture からのみ作ります。

capture が未観測なら:

```text
adapter_stdout = null
adapter_stderr = null
```

capture が観測済みなら:

```text
allowed        = captured_bytes <= configured capture limit
measured_bytes = captured_bytes
retained_bytes = capture_retained_bytes
```

`allowed` は capture byte boundary の結果です。

runtime success/failure や EOF の semantic classification と混同しません。

native numeric check は `type(value) is int` とし、Python の `bool` を整数として受けません。

---

## 20. Actual-zero fixture

null と zero の差を明示する fixture を追加します。

提案名:

```python
observed_zero_capture_candidates_v3(tmp_path)
```

spawn 後の正規 runtime failure route を使い、capture object 自体は存在させます。

adapter stdout/stderr の actual counts は 0 にします。

expected final measurement は:

```text
adapter_stdout = {allowed: true, measured_bytes: 0, retained_bytes: 0}
adapter_stderr = {allowed: true, measured_bytes: 0, retained_bytes: 0}
```

null/null にはしません。

stage-failed null/null case と同じ test parameter に押し込まず、別 behavior として Red→Green にします。

---

## 21. Response-link rule

eligible response link は caller metadata から作りません。

validated Core の場合だけ、same run/runtime/Core の actual receipt/candidate から次を再導出します。

- `request_id`
- `raw_sha256`
- `model_digest`
- `byte_length`

validated Core が SOURCE-003 / TARGET / EXPORT / entity-budget unavailable でも、publication が `payload_unavailable` でなければ eligible response link を保持します。

`RejectedSemanticDecisionV3` は response link を公開しません。

runtime-only failure も response `null` です。

capture overflow または final stderr overflow のときは validated Core でも response `null` にします。

---

## 22. Artifact rule

artifact bytes は `RetainedRequestBoundPublicationCandidatesV3.artifacts()` の actual nominal owners からのみ取得します。

descriptor は actual bytes の size/hash と再照合します。

validated Core unavailable、Rejected Core、runtime-only failure は artifacts 空です。

`payload_unavailable` は元 candidates に artifact があった場合でも final artifacts を空にします。

selected-copy overflowだけなら semantic artifacts は保持します。

caller-supplied bytes/descriptor は factory signature に入れません。

---

## 23. Selected stdout algorithm

configured limit は request-owned:

`max_selected_stdout_bytes = 16777216`

limit override を final factory に追加しません。

selected candidate を一度だけ pre-copy measurement します。

artifact selector の場合は actual candidate owner の exact bytes/descriptor を使用します。

manifest / summary selector は existing publication semantics の二段階 algorithm を v3 owner に適応します。

legacy `PublicationBoundaryDecision` を再利用せず、status algorithm だけを保持します。

pre-copy measurement は次を保持します。

- original byte length
- original SHA-256
- allowed
- retained bytes length

overflow 後の typed replacement stdout は別 bytes です。

replacement の長さ/hash で original measurement を上書きしません。

replacement を「元 candidate」として二回目の selected measurement に通しません。

---

## 24. Final public stderr algorithm

configured limit:

`max_stderr_bytes = 65536`

順序を固定します。

1. base public diagnostics を owner から導出する。
2. capture overflow の有無を owner measurement から決める。
3. selected pre-copy measurement を必要な場合だけ一回行う。
4. selected overflow なら publication-scope `CSV-NEXT-LIMIT-003` を diagnostics へ追加する。
5. **この final diagnostic list を一度だけ canonical JSONL encode する。**
6. encoded byte length を一度だけ測定する。
7. `<= 65536` なら全 bytes を stderr として保持する。
8. `> 65536` なら partial write は 0、stderr bytes は空、manifest diagnostic は `CSV-NEXT-LIMIT-003` 一件とする。

「まず base stderr を測り、selected failure 診断追加後に再測定する」実装は禁止します。

最初の measurement を後から上書きする設計も禁止します。

---

## 25. Publication precedence

final outcome の precedence は次です。

```text
capture overflow
    -> payload_unavailable
else selected pre-copy overflow
    -> candidate selected_artifact_unavailable
else
    -> published

その後 final stderr overflow
    -> payload_unavailable へ上書き
```

stderr overflow が selected-copy failure より後に判明しても、最終 result は `payload_unavailable` です。

この precedence は semantic decision を変更しません。

---

## 26. Public stderr 64 KiB actual fixture

`next_final_publication_v2_fixtures.py` に configured-cap reachability fixture を作ります。

limit を 10 bytes 等へ縮めてはいけません。

fake diagnostic rows を直接 finalizer へ注入してはいけません。

推奨方法は、既存 SI-06 admission で到達済みだった「複数の合法 missing targets + path length calibration」を v3 actual-owner chain へ適応することです。

fixture は actual:

```text
sealed source
-> request with explicit targets
-> validated response/proof
-> ValidatedSemanticDecisionV3
-> run-v3
-> candidates-v3
-> public diagnostics
```

を通します。

target path の合法な長さだけで JSONL size を調整します。

padding bytes は追加しません。

目標は二つです。

```text
final diagnostic JSONL = 65,536 bytes
final diagnostic JSONL = 65,537 bytes
```

exact case は full stderr bytes を保持します。

+1 case は:

- stderr empty
- partial-write 0
- `public_stderr.allowed == false`
- measured bytes 65,537
- retained bytes 0
- publication `payload_unavailable`
- manifest diagnostic `CSV-NEXT-LIMIT-003` exactly one

とします。

旧 v2 probe の hash/length を新 v3 expected literal として流用しません。

new fixture の expected JSONL は test-side independent JSON encoder で算出し、producer と別経路で length/hash を固定します。

---

## 27. Selected stdout 16 MiB actual fixture

既存:

`tests/contracts/next_publication_candidates_v2_fixtures.py`

の `available_large_json_run()` / `_long_case_inputs()` は、実 filesystem/source-seal と合法 path/context bytes で 16 MiB exact/+1 を到達させる方法の参考にします。

**v2 run owner 自体を v3 に cast してはいけません。**

`next_final_publication_v2_fixtures.py` に v3-profile equivalent を作ります。

条件:

- actual files
- actual `SourceAcquisitionSeal`
- actual v3 proof/source inventory
- actual `ValidatedSemanticDecisionV3`
- actual run-v3
- actual candidates-v3
- actual public artifact bytes
- no appended artifact padding
- no fake descriptor
- no limit shrink
- no fake Core
- no fake entity count

到達値:

```text
16,777,216 bytes
16,777,217 bytes
```

exact case:

- selected measurement allowed
- measured 16,777,216
- retained 16,777,216
- copy status published

+1 case:

- selected measurement not allowed
- measured 16,777,217
- retained 0
- original candidate descriptor size/hash preserved
- publication outcome `selected_artifact_unavailable`
- exit 3
- eligible response link preserved
- semantic status unchanged

typed replacement stdout の size/hash は original 16,777,217 measurement と別に assert します。

---

## 28. Semantic/publication axis matrix tests

一つずつ vertical Red→Green にします。

### Validated SOURCE-003

既存 `core_inputs_v3` と `exclude_value_module_with_root_v3` の正規 route を使います。

expected:

- run semantic `payload_unavailable`
- final publication `published`
- exit 3
- response non-null
- artifacts empty
- catalog SOURCE-003 diagnostic
- capture が通常観測済みなら adapter pair object/object

### TARGET unavailable

`omit_selected_button_module_v3` 等の current legal target fixture を使います。

expected は SOURCE-003 と同じ publication axis ですが TARGET diagnostic/ref を維持します。

### EXPORT unavailable

current v3 export-failure helperを使い、validated Core の export failure とします。

response link を保持します。

### Entity-budget unavailable

actual `max_entities` gate を使用します。

count を fake metadata で差し替えません。

response link を保持します。

### Rejected Core

`inspect_semantic_candidate_v3` で actual rejection を作ります。

expected:

- publication `published`
- exit 3
- response null
- artifacts empty

### Runtime-only stage failure

actual stage-failed runtime を使います。

expected:

- publication `published`
- exit 3
- response null
- artifacts empty
- adapter capture null/null

---

## 29. Capture overflow tests

current runtime-v2 failure routesの actual `stdout_limit` / `stderr_limit` constructionを再利用します。

configured cap + 1 の actual observation を作ります。

final expected:

- adapter pair object/object
- overflowing stream `allowed=false`
- `measured_bytes=limit+1`
- retained 0
- publication `payload_unavailable`
- response null
- artifacts empty
- public diagnostic LIMIT-003
- selected copy not used to recover publication

capture overflow を null へ変換しません。

---

## 30. Same-owner / tamper negative tests

次を individual negative behavior として追加します。

- one-sided null in projected record
- unobserved capture zero-fill
- observed-zero capture nullification
- candidate capture count mutation
- retained count mutation
- allowed mutation
- foreign candidates owner
- equal-content foreign run owner
- foreign artifact owner
- response metadata substitution
- candidate descriptor substitution
- selected measurement substitution
- public stderr measurement substitution
- final outcome substitution
- exit code substitution
- seal/cache rehash after mutation
- version `2.0`
- version `True`
- measured count float
- measured count bool
- retained count float
- retained count bool

validator は「mutated record と mutated private cache が一致する」だけでは受理しません。

actual owner/bytes から独立に再導出します。

---

## 31. Privacy tests

actual final projectionを再帰走査し、少なくとも次を禁止します。

- `proof`
- `content_base64` の source/proof private copy
- raw child stderr
- raw private response body
- process control object
- PID
- cwd
- host path
- private acquisition ledger
- proof-only affected path collection

public artifact 自身の schema-authorized `bytes_base64` は別です。

同名 key の機械的全面禁止ではなく、schema-authorized artifact bytes と private bytes を区別します。

diagnostic path は catalog の `ref_permission` と same-owner evidence が許可したものだけです。

---

## 32. Schema-only evidence と owner evidence の分離

`tests/contracts/test_next_public_family_v3_schemas.py` は schema/ref closure の証拠です。

ここで null pair が validate しても final owner proof とは呼びません。

final owner の証拠は:

`tests/contracts/test_next_final_publication_v2.py`

で actual nominal owners を通して行います。

同様に literal outer vector の dummy seal/hash を single final owner proof として扱いません。

---

## 33. Existing object/object compatibility

現行 SI-05 `outer_vectors` の object/object publication record をそのまま valid に保ちます。

新 schema correction によって旧 object/object record を壊してはいけません。

`schema` identity/version/URN は変えません。

outer exact refs:

- `next-domain-manifest-v2` → `next-run-decision-v3`
- `next-domain-manifest-v2` → `next-publication-decision-v2`
- `run-manifest-v2` → `next-run-decision-v3`
- `run-manifest-v2` → `next-publication-decision-v2`
- `stdout-result-v2` → `next-publication-decision-v2`

を保持します。

`next-publication-decision-v2.candidates` は exact `next-publication-candidates-v3` ref のままです。

---

## 34. Python / SQLAlchemy and legacy regressions

次を変更しません。

- Python semantic golden bytes
- SQLAlchemy semantic golden bytes
- old root branch meanings
- old dispatcher routing
- old KAT
- old Next leaf schema semantics

`test_legacy_python_sqlalchemy_dispatcher_and_root_branch_meanings_are_unchanged` を含む既存 regression を通します。

nullable correction を generic measurement schema や old v1 schema へ広げません。

---

## 35. Recommended vertical TDD sequence

horizontal に全 test を先に生成しません。

順序は次で固定します。

1. actual stage-failed candidates fixture
2. null/null publication schema Red
3. minimal nullable-pair schema Green
4. one-null/public-stderr-null/selected-null schema negatives
5. runtime NODE-002 public diagnostic Red→Green
6. diagnostic independent validator Red→Green
7. SOURCE-003 actual root diagnostic Red→Green
8. TARGET diagnostic Red→Green
9. EXPORT / entity-budget diagnostic Red→Green
10. base complete `RetainedFinalPublicationV2` Red→Green
11. null/null final-owner projection Red→Green
12. actual-zero object/object Red→Green
13. validated unavailable publication-axis case一件
14. remaining validated unavailable cases
15. rejected Core case
16. runtime-only case
17. capture overflow case
18. configured 64 KiB exact stderr
19. configured 64 KiB +1 stderr
20. configured 16 MiB exact selected copy
21. configured 16 MiB +1 selected copy
22. selected-overflow + later stderr-overflow precedence
23. foreign-owner/cache/native-type negatives
24. privacy closure
25. outer schema / old KAT / Python / SQLAlchemy regressions

routine Refactor は各 Green の直後に必要最小限だけ行います。

behavior がまだ Red でない段階で次の branch を大量実装しません。

---

## 36. Focused commands during TDD

最初の schema Red:

```bash
uv run pytest tests/contracts/test_next_public_family_v3_schemas.py -q \
  -k 'publication_v2_accepts_unobserved_capture_null_pair'
```

diagnostic slice:

```bash
uv run pytest tests/contracts/test_next_public_diagnostic_v3.py -q
```

final owner slice:

```bash
uv run pytest tests/contracts/test_next_final_publication_v2.py -q
```

schema/ref regression:

```bash
uv run pytest \
  tests/contracts/test_next_public_family_v3_schemas.py \
  tests/contracts/test_json_schemas.py \
  -q
```

adjacent actual-owner regression:

```bash
uv run pytest \
  tests/contracts/test_next_provenance_v3.py \
  tests/contracts/test_next_semantic_core_v3.py \
  tests/contracts/test_next_run_decision_v3.py \
  tests/contracts/test_next_publication_candidates_v3.py \
  tests/contracts/test_next_public_diagnostic_v3.py \
  tests/contracts/test_next_final_publication_v2.py \
  -q
```

legacy publication/KAT regression:

```bash
uv run pytest tests/contracts/test_next_contracts.py -q
```

large exact/+1 casesを `-k` や marker で aggregate gate から除外しません。

---

## 37. Required local aggregate gates

focused Green の後、同じ candidate で次を実行します。

```bash
uv run pytest tests/contracts -q --tb=short
```

```bash
uv run pytest -q
```

type check:

```bash
uv run mypy src tests
```

lint:

```bash
uv run ruff check .
```

format:

```bash
uv run ruff format --check .
```

SpecDock:

```bash
python3 ./spec-dock/scripts/spec-dock sync
python3 ./spec-dock/scripts/spec-dock validate
```

diff hygiene:

```bash
git diff --check
```

repository cleanliness:

```bash
git status --short
```

生成した `node_modules` を残しません。

この SI-06 local gate では package/offline wheel/macOS/actual TS/production CLI の成功を主張しません。

それらは `.github/workflows/ci.yml` に別 lane が存在していても、本 unit の local reference acceptance の代用ではありません。

---

## 38. Scope-diff guard

SI-06 implementation candidate では、元 base から次の lower-owner/product files が変わっていないことを確認します。

```bash
git diff --exit-code \
  af6f5d33f9487a33dabf2ddfe41df85b3d8267fb..HEAD -- \
  src \
  pyproject.toml \
  uv.lock \
  tests/contracts/next_runtime_v2_reference.py \
  tests/contracts/next_runtime_v2_validation.py \
  tests/contracts/next_semantic_core_v3_reference.py \
  tests/contracts/next_semantic_core_v3_validation.py \
  tests/contracts/next_run_decision_v3_reference.py \
  tests/contracts/next_run_decision_v3_validation.py \
  tests/contracts/next_publication_candidates_v3_reference.py \
  tests/contracts/next_publication_candidates_v3_validation.py
```

この command が差分を返した場合、単に whitelist を広げません。

その変更が本当に accepted SI-06 scope 内かを先に判定します。

---

## 39. Completion evidence required per boundary

capture pair:

- actual stage-failed null/null
- actual observed-zero object/object
- one-sided null rejected
- owner mismatch rejected

diagnostics:

- actual runtime failure
- actual SOURCE-003 parse/read root
- TARGET
- EXPORT
- entity-budget
- catalog exact metadata
- no private evidence leak

stderr:

- configured 65,536 exact
- configured 65,537 +1
- one final encode/measurement
- +1 partial write 0
- empty stderr
- manifest LIMIT-003 exactly one

selected stdout:

- actual 16,777,216 exact
- actual 16,777,217 +1
- original descriptor retained
- replacement bytes separate
- original measurement not overwritten

publication axes:

- validated unavailable / published / response retained
- rejected / published / response null
- runtime-only / published / response null
- capture overflow / payload_unavailable
- stderr overflow / payload_unavailable
- selected overflow / selected_artifact_unavailable
- stderr overflow overrides prior selected failure

ownership:

- equal-content foreign owner rejected
- rehashed cache mutation rejected
- native integer restrictions enforced

compatibility:

- existing object/object v2 vectors still valid
- exact refs unchanged
- Python/SQLAlchemy regressions unchanged
- old leaf/KAT unchanged

---

## 40. Seal/hash discipline

publication record の seal/hash は existing publication semantics を維持します。

新しい capture-null discriminator や hidden fallback field を hash preimage へ追加しません。

projection済み null/object pair は existing `measurements` surface の値としてそのまま seal 対象になります。

caller-provided seal/hash は受けません。

validator は stored seal と record の自己整合だけでなく、actual candidates/run/artifact/stderr/stdout bytes から再計算します。

schema-only fixture の dummy seal を final-owner evidence として流用しません。

---

## 41. Consumer compatibility boundary

この change は同じ v2 wire identity の限定訂正です。

既存 object/object records は継続して valid です。

一方、旧 object-only consumer は新 null/null record を拒否します。

したがって reference implementation completion と consumer rollout authorization は別です。

実装・schema・validator・vectors は同一 candidate で coordinated change とします。

rollback もこの集合を同時に戻します。

「external/persistent consumer がない」と仮定して migration/send を進めません。

external/persistent consumer が v2 object-only invariance を契約上要求していることが確認された場合は、この brief の実装 continuation を停止します。

その場合は versioning/dual-reader 等を勝手に実装せず decision package に戻します。

---

## 42. Fresh cumulative Code Review gate

local gates がすべて Green になった後、candidate を clean commit/push します。

その exact full SHA を GitHub connector で再確認します。

その後、SI-06 の fresh cumulative Code Review Strict を実行します。

review range の base は固定:

`af6f5d33f9487a33dabf2ddfe41df85b3d8267fb`

candidate SHA が進んでも base は移動しません。

requested reviewer setting:

- GPT-5.6 Sol
- Extra High

valid acceptance は少なくとも:

- exact repository/branch/SHA verification success
- schema-valid review response
- `review_status=pass`
- P0 = 0
- P1 = 0

です。

reviewer が local tests を実行したとは扱いません。

local command evidence と reviewer evidence は分離します。

P2/P3 は自動 scope expansion / automatic remediation の理由にしません。

修正が必要な finding を採択した場合は、同じ `af6f5d...` base から新 candidate SHA への fresh cumulative review を再実行します。

この authoring conversation はその Code Review を代用しません。

---

## 43. Implementer execution setting

caller-visible primary implementer setting は:

- model: `gpt-6.1-sol`
- reasoning: `max`

です。

backend identity は未検証です。

この brief はその設定に合わせ、内部判断を残さない owner/invariant/Red→Green 順序を具体化していますが、model-specific capability を仮定しません。

`luna-max-implement` は sequence/gate の参考資料に限り、model 設定変更や backend proof として使用しません。

subagents は使用しません。

reviewer、Code Review、Final Quality Gate を implementer conversation 内の自己レビューで代用しません。

長時間 Oracle は元 session/log で完了を待ち、UI progress polling や無出力を理由に同一 request を再送しません。

---

## 44. Stop conditions

以下のいずれかが必要になった時点で implementation-ready brief としては停止します。

1. `next-publication-decision/v2` の wire identity/version を変更する必要が出た。
2. successor URN、dual writer、fallback union が必要になった。
3. external/persistent consumer が old v2 object-only invariant を要求すると確認された。
4. new catalog code/message/ref-permission が必要になった。
5. public security/privacy rule の変更が必要になった。
6. proof-only private path/bytes を公開しないと diagnostic を構築できない。
7. lower runtime/Core/run/candidates owner の意味変更が必要になった。
8. capture を再取得しないと final publication を構築できない。
9. File/Module owner-closed rule または source inventory/safe-subset semantics の変更が必要になった。
10. ASSET policy 判断が必要になった。
11. reader-prefix policy 判断が必要になった。
12. actual 64 KiB / 16 MiB fixture が fake count、padding、limit shrink、fake seal を使わないと到達できない。
13. old Python/SQLAlchemy/KAT meaning を変えないと Green にできない。
14. production/OS/TS/CLI/package change が必要になった。

停止時は implementation を押し切らず、観測した矛盾、影響する authority、必要な decision を分離した decision package を返します。

---

## 45. Definition of done for SI-06 reference unit

SI-06 reference unit の completion は、次をすべて満たしたときだけです。

- physical publication-v2 schema が nullable capture pair を正しく表す
- existing object/object v2 record が維持される
- actual null/null と actual zero object/object が別に証明される
- catalog-owned diagnostics が actual v3 owners から生成される
- diagnostic validator が producer/cache から独立している
- single final owner が candidates-v3 一つだけを authority input にする
- semantic outcome と publication outcome が分離される
- eligible response-link rules が matrix どおりである
- capture overflow / selected overflow / stderr overflow precedence が閉じる
- public stderr 64 KiB exact/+1 が configured cap で到達する
- selected stdout 16 MiB exact/+1 が actual candidate bytes で到達する
- selected replacement が original pre-copy measurement を上書きしない
- partial write は 0
- raw/private evidence を公開しない
- foreign/equal-content/cache/native-type attacks を拒否する
- outer exact refs と old schema meanings を維持する
- Python/SQLAlchemy/old KAT regressions が Green
- contracts aggregate が Green
- full pytest が Green
- mypy が Green
- ruff check / format check が Green
- SpecDock sync / validate が Green
- diff check が Green
- scope-diff guard が Green
- candidate が clean/pushed
- exact candidate SHA を再検証済み
- fixed `af6f5d...` base から fresh cumulative Code Review Strict が valid pass、P0/P1=0

この完了は SI-06 reference implementation の認定だけです。

全 A02/A03、reader prefix、actual TypeScript/OS/CLI/package、production、Final Quality Gate、Issue #8 全体の完了を意味しません。
