# File Operations

## v2 package path identity

- Package directory prefixes are lowercase ASCII: `issue-01` through `issue-07`.
- Semantic stable sequence keys remain uppercase: `ISSUE-01` through `ISSUE-07`.
- Lowercase package paths do not predict or replace the actual `iss-NNNNN` identity allocated later by SpecDock.
- This v2 package replaces original ZIP SHA-256 `f346e38dd218f13fdcd796ba45af82397cb7cc078336ff3c331b44b4b0eb8c20` and does not authorize repository mutation.
## Operation semantics

| Operation | Meaning | Safety gate |
| --- | --- | --- |
| replace | Reuse an existing canonical node and replace requirement/design/plan as complete files. | SOURCE-BASELINE path SHA-256 must match; do not edit metadata/report. |
| create-node-then-copy | Create a SpecDock Issue through approved command, record allocated path, then copy complete R/D/P files. | No predicted iss ID; add dependency through SpecDock; validate after copy. |
| import-artifact | Import HTML/assessment/matrix as opaque evidence. | Evidence does not become accepted authority automatically. |
| preserve | Retain exact existing bytes and history. | No rewrite/rename/delete. |
| defer | Do not perform in specification adoption. | Requires later accepted Issue/Epic and independent verification. |

## replace

- `package/initiative/requirement.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/requirement.md`
- `package/initiative/design.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/design.md`
- `package/initiative/plan.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/plan.md`
- `package/epic/requirement.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/requirement.md`
- `package/epic/design.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/design.md`
- `package/epic/plan.md` → `spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/plan.md`

Replace only after each destination SHA-256 equals `SOURCE-BASELINE.json`。Use whole-file bytes; do not patch template fragments into previous text。

## create-node-then-copy

MANIFEST order で recommended title/slug を使って seven Issue nodes を作成する。各 node では SpecDock が返した actual path と identity mapping を使い、materialized whole file を copy する:

`ISSUE-NN` stable key から actual node identity への materialization は `adoption-plan.md` の限定 contract に従う。frontmatter ID、H1 scope ID、関連GitHubだけを actual valueへ置換し、`package_sequence_key` とすべての trace ID/content を保持する。materialized file の SHA-256 を記録後、whole-file copy する。

- `package/issues/issue-01-generate-python-structure-snapshots/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `generate-python-structure-snapshots`
- `package/issues/issue-02-compare-python-structure-changes-safely/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `compare-python-structure-changes-safely`
- `package/issues/issue-03-generate-sqlalchemy-er-snapshots/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `generate-sqlalchemy-er-snapshots`
- `package/issues/issue-04-compare-sqlalchemy-er-changes/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `compare-sqlalchemy-er-changes`
- `package/issues/issue-05-generate-nextjs-component-snapshots/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `generate-nextjs-component-snapshots`
- `package/issues/issue-06-compare-nextjs-component-changes/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `compare-nextjs-component-changes`
- `package/issues/issue-07-run-unified-multi-domain-structure-comparison/requirement.md`, `design.md`, `plan.md` → newly allocated Issue node for `run-unified-multi-domain-structure-comparison`

approved SpecDock operation で MANIFEST `dependency_dag` と完全一致する dependency edge を追加する。`.meta.json` を直接編集せず、actual ID を推測しない。

## import-artifact

- each `explanation.html` → corresponding Initiative/Epic/Issue Artifact store as specification evidence。
- `package/artifacts/*.md` → Initiative Artifact store by default, preserving bytes and package source name in import provenance。
- imported evidence remains subordinate to adopted R/D/P and accepted ADR。

## preserve

- all existing `.meta.json` and `report.md`。
- exact interview and 8 accepted ADR files listed in SOURCE-BASELINE。
- SpecDock runtime/templates/guides/rules/symlinks/version and GitHub mapping。
- existing `iss-00003` bytes/history until approved supersede/close operation is recorded。

## defer

- production implementation/tests/docs/lockfiles/CI: defer to Issue execution after specification adoption。
- `iss-00003` supersede comment/close: defer until actual ISSUE-02 node ID exists; perform through approved SpecDock/GitHub workflow。
- legacy source code copy: defer until license/provenance review; initial Plans require clean repository-owned implementation。
- product HTML report/command/Tailscale publication: future separate Epic only。

## Prohibited

- direct repository metadata modification、path rename、Git commit/push/merge、tracker mutation by this ZIP。
- partial file merge that leaves template text or old requirements mixed with package content。
- deleting or rewriting accepted ADR/interview。
