# Adoption Plan

## Baseline

- repository: `chemitaro/code-structure-viz`
- branch: `main`
- full SHA: `7951ddabc2e6a3d66edb77eada7c6c16923264f7`
- Initiative: `init-00001` / `Visualize Code Structure Changes`
- exactly one Epic: `epic-00002` / `Establish Safe Git Structure Comparison`
- provisional Issue: `iss-00003` / `Define Git Comparison Conformance Contract` / `git-comparison-conformance-contract`
- package は `.meta.json`、GitHub state、repository file、ref、tracker node を直接変更しない。

## Existing node disposition

### Initiative and Epic

- existing `init-00001` と `epic-00002` の node/title/slug を再利用する。
- SOURCE-BASELINE の hash 検証後、canonical `requirement.md`、`design.md`、`plan.md` だけを whole-file replace する。
- existing `.meta.json`、`report.md`、accepted ADR、interview、rules symlink、GitHub mapping を保持する。

### iss-00003

**推奨: node は supersede し、concern は ISSUE-02 に採用する。**

理由:

1. current title/slug defines a horizontal contract-only boundary, while accepted ADR requires observable vertical outcomes。
2. ISSUE-02 owns named Git comparison end-to-end with Python semantic JSON/PlantUML/acceptance, so the useful concern has a clear home。
3. `.meta.json` is SpecDock-managed/do-not-edit, and evidence does not confirm a safe title/slug rename command。Direct filesystem rename is prohibited。
4. preserving and closing/superseding the scaffold gives a clearer audit trail than silently changing node identity。

seven new Issues の作成後、approved SpecDock/GitHub workflow で `iss-00003`/GitHub #3 から実際の ISSUE-02 node への superseded-by reference を記録し、close する。旧 template R/D/P は ISSUE-02 へ流用せず、package の ISSUE-02 canonical content を identity materialization 後に whole-file copy する。

## Issue 作成順 manifest

| Stable key | Recommended title | lowercase slug | Dependencies | Node action |
| --- | --- | --- | --- | --- |
| ISSUE-01 | Generate Python Structure Snapshots | generate-python-structure-snapshots | なし | new SpecDock Issue node |
| ISSUE-02 | Compare Python Structure Changes Safely | compare-python-structure-changes-safely | ISSUE-01 | new SpecDock Issue node |
| ISSUE-03 | Generate SQLAlchemy ER Snapshots | generate-sqlalchemy-er-snapshots | ISSUE-01 | new SpecDock Issue node |
| ISSUE-04 | Compare SQLAlchemy ER Changes | compare-sqlalchemy-er-changes | ISSUE-02, ISSUE-03 | new SpecDock Issue node |
| ISSUE-05 | Generate Next.js Component Snapshots | generate-nextjs-component-snapshots | ISSUE-01 | new SpecDock Issue node |
| ISSUE-06 | Compare Next.js Component Changes | compare-nextjs-component-changes | ISSUE-02, ISSUE-05 | new SpecDock Issue node |
| ISSUE-07 | Run Unified Multi-Domain Structure Comparison | run-unified-multi-domain-structure-comparison | ISSUE-04, ISSUE-06 | new SpecDock Issue node |

SpecDock は actual `iss-NNNNN` ID を割り当てる。package の `ISSUE-NN` は stable sequence key であり metadata placeholder ではない。copy 前に returned actual ID/path/GitHub issue number を stable key へ対応付け、下記 identity materialization を行う。package 内で actual ID を予測しない。

### Issue identity materialization contract

Issue package filesは完成した内容を持つが、scope identity は allocation 前の stable key で表す。actual node 作成後、adoption tool は次の限定 transformation だけを適用して materialized R/D/P を生成し、その file 全体を destination へ copy する。

1. frontmatter `ID: "ISSUE-NN"` を actual `iss-NNNNN` に置換する。
2. H1 の先頭 scope ID `ISSUE-NN` を同じ actual ID に置換する。
3. frontmatter `関連GitHub: []` を作成済み actual GitHub Issue reference に置換する。
4. `package_sequence_key: "ISSUE-NN"` は trace alias として保持する。
5. Requirement/Design/Plan/Acceptance/Test の `I01-*` 等の stable trace ID、本文、title、slug、dependency semantics は変更しない。

この transformation は package 内容の推敲や partial merge ではない。actual identity を割り当てる deterministic adoption step であり、materialized file の SHA-256 を adoption log に記録してから whole-file copy する。

## Whole-file copy targets

| Package source | Repository destination rule | Operation |
| --- | --- | --- |
| package/initiative/requirement.md | spec-dock/initiatives/init-00001-code-structure-visualization/requirement.md | replace |
| package/initiative/design.md | spec-dock/initiatives/init-00001-code-structure-visualization/design.md | replace |
| package/initiative/plan.md | spec-dock/initiatives/init-00001-code-structure-visualization/plan.md | replace |
| package/epic/requirement.md | spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/requirement.md | replace |
| package/epic/design.md | spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/design.md | replace |
| package/epic/plan.md | spec-dock/initiatives/init-00001-code-structure-visualization/epics/epic-00002-safe-git-structure-comparison/plan.md | replace |
| package/issues/issue-01-generate-python-structure-snapshots/requirement.md | path returned by `spec-dock new issue` for slug `generate-python-structure-snapshots`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-01-generate-python-structure-snapshots/design.md | path returned by `spec-dock new issue` for slug `generate-python-structure-snapshots`, then `design.md` | create-node-then-copy |
| package/issues/issue-01-generate-python-structure-snapshots/plan.md | path returned by `spec-dock new issue` for slug `generate-python-structure-snapshots`, then `plan.md` | create-node-then-copy |
| package/issues/issue-02-compare-python-structure-changes-safely/requirement.md | path returned by `spec-dock new issue` for slug `compare-python-structure-changes-safely`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-02-compare-python-structure-changes-safely/design.md | path returned by `spec-dock new issue` for slug `compare-python-structure-changes-safely`, then `design.md` | create-node-then-copy |
| package/issues/issue-02-compare-python-structure-changes-safely/plan.md | path returned by `spec-dock new issue` for slug `compare-python-structure-changes-safely`, then `plan.md` | create-node-then-copy |
| package/issues/issue-03-generate-sqlalchemy-er-snapshots/requirement.md | path returned by `spec-dock new issue` for slug `generate-sqlalchemy-er-snapshots`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-03-generate-sqlalchemy-er-snapshots/design.md | path returned by `spec-dock new issue` for slug `generate-sqlalchemy-er-snapshots`, then `design.md` | create-node-then-copy |
| package/issues/issue-03-generate-sqlalchemy-er-snapshots/plan.md | path returned by `spec-dock new issue` for slug `generate-sqlalchemy-er-snapshots`, then `plan.md` | create-node-then-copy |
| package/issues/issue-04-compare-sqlalchemy-er-changes/requirement.md | path returned by `spec-dock new issue` for slug `compare-sqlalchemy-er-changes`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-04-compare-sqlalchemy-er-changes/design.md | path returned by `spec-dock new issue` for slug `compare-sqlalchemy-er-changes`, then `design.md` | create-node-then-copy |
| package/issues/issue-04-compare-sqlalchemy-er-changes/plan.md | path returned by `spec-dock new issue` for slug `compare-sqlalchemy-er-changes`, then `plan.md` | create-node-then-copy |
| package/issues/issue-05-generate-nextjs-component-snapshots/requirement.md | path returned by `spec-dock new issue` for slug `generate-nextjs-component-snapshots`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-05-generate-nextjs-component-snapshots/design.md | path returned by `spec-dock new issue` for slug `generate-nextjs-component-snapshots`, then `design.md` | create-node-then-copy |
| package/issues/issue-05-generate-nextjs-component-snapshots/plan.md | path returned by `spec-dock new issue` for slug `generate-nextjs-component-snapshots`, then `plan.md` | create-node-then-copy |
| package/issues/issue-06-compare-nextjs-component-changes/requirement.md | path returned by `spec-dock new issue` for slug `compare-nextjs-component-changes`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-06-compare-nextjs-component-changes/design.md | path returned by `spec-dock new issue` for slug `compare-nextjs-component-changes`, then `design.md` | create-node-then-copy |
| package/issues/issue-06-compare-nextjs-component-changes/plan.md | path returned by `spec-dock new issue` for slug `compare-nextjs-component-changes`, then `plan.md` | create-node-then-copy |
| package/issues/issue-07-run-unified-multi-domain-structure-comparison/requirement.md | path returned by `spec-dock new issue` for slug `run-unified-multi-domain-structure-comparison`, then `requirement.md` | create-node-then-copy |
| package/issues/issue-07-run-unified-multi-domain-structure-comparison/design.md | path returned by `spec-dock new issue` for slug `run-unified-multi-domain-structure-comparison`, then `design.md` | create-node-then-copy |
| package/issues/issue-07-run-unified-multi-domain-structure-comparison/plan.md | path returned by `spec-dock new issue` for slug `run-unified-multi-domain-structure-comparison`, then `plan.md` | create-node-then-copy |

## explanation HTML と Artifact import

- `package/initiative/explanation.html`, `package/epic/explanation.html`, and each Issue `explanation.html` are specification evidence. Import with approved `spec-dock artifact import file` at the corresponding node; do not add product HTML commands or runtime output paths。
- files under `package/artifacts/` are evidence imports at Initiative scope unless a later human decision assigns them to Epic/Issue scope. Import source bytes opaquely; do not infer accepted authority from filename。
- R/D/P are canonical candidates after adoption; HTML and assessment/matrix files remain evidence。

## Preserve set

Preserve without rewrite:

- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t025616z-interview-codestructureviz-specification-interview.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030220z-adr-independent-product-ownership.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030221z-01-adr-named-git-comparison-endpoints.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030221z-02-adr-domain-adapter-boundaries.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030221z-03-adr-agent-first-artifact-contract.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030221z-adr-dual-snapshot-semantic-diff.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030222z-01-adr-static-analysis-safety-boundary.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030222z-02-adr-exclude-product-html-reports.md
- spec-dock/initiatives/init-00001-code-structure-visualization/artifacts/20260824t030222z-adr-vertical-issue-slicing.md

Also preserve all current `.meta.json`, `report.md`, SpecDock runtime/templates/guides, rules symlinks, and `spec-dock.version`。

## Deferred operations

- production implementation, tests, lockfiles, CI changes: deferred to accepted Issue execution。
- product HTML report/command/Tailscale publication: deferred to a future separately approved Epic, not this package。
- legacy code copy: deferred unless license/provenance is independently verified; current Plans use clean repository-owned implementation and behavioral evidence only。

## Validation and adoption order

1. Verify repository/branch/full SHA equals SOURCE-BASELINE and working tree is clean according to local adoption policy。
2. Verify every current canonical R/D/P path SHA-256 in SOURCE-BASELINE before replace。
3. Verify ZIP, MANIFEST, CHECKSUMS, path safety, no symlink/duplicate, UTF-8/LF/no trailing whitespace/no placeholder。
4. Run all explanation HTML through the provided validator in the adoption environment; compare with VALIDATION.md。
5. Run `python3 ./spec-dock/scripts/spec-dock validate` on unchanged baseline。
6. Replace Initiative/Epic R/D/P as whole files; run SpecDock validate。
7. Create seven Issue nodes in topological/stable order and record actual IDs/paths; add dependencies through approved SpecDock command/API。
8. Copy each Issue R/D/P whole to the returned node path; run validate after each node or atomic batch according to local policy。
9. Import explanation HTML and package artifacts as evidence; preserve accepted ADR/interview unchanged。
10. Mark `iss-00003` superseded by actual ISSUE-02 node through approved workflow; do not direct-edit metadata。
11. Run `spec-dock sync`, `spec-dock validate`, dependency/DAG verification, Git diff review, then commit through Codex/user workflow。

## Rollback

- Before commit: restore Initiative/Epic canonical R/D/P from SOURCE-BASELINE bytes/hash, delete newly created nodes through approved SpecDock delete only if policy permits and no external references exist; otherwise mark abandoned/superseded。
- After commit: revert adoption commit as a whole, preserving accepted ADR/interview and node audit history。
- Imported evidence may be retained for audit if deletion would lose provenance; canonical authority returns to baseline R/D/P on rollback。
