# Validation

## Source verification

- connected GitHub repository: `chemitaro/code-structure-viz`
- verified branch: `main`
- exact full tip SHA: `7951ddabc2e6a3d66edb77eada7c6c16923264f7`
- strict verification result: connected GitHub branch object の full SHA が byte-for-byte で一致した後にのみ、添付 findings と original ZIP を使用した。
- repository instruction result: verified commit の root に `AGENTS.md` は存在しない（exact ref で 404 を確認）。
- original ZIP SHA-256: `f346e38dd218f13fdcd796ba45af82397cb7cc078336ff3c331b44b4b0eb8c20`
- supplied `local-validation-findings.md` SHA-256: `220adc9587ca68b267633725090522a758671f81de358e1ebce42ac1d0e82f44`
- source baseline: accepted ADR 8件、interview 1件、現 canonical R/D/P 9件、node metadata 3件の verified paths/hashes を `SOURCE-BASELINE.json` に保持した。

## v2 repair scope and preservation

- Issue package directory prefixesを `issue-01` から `issue-07` の lowercase ASCII へ変更した。文書内と manifest field の semantic sequence key `ISSUE-01` から `ISSUE-07` は変更していない。
- original ZIP で browser hard failure だった4図は、quoted element label 内の physical newline を PlantUML 1.2026.6 の明示的な `\n` escape に置換した。図の意味、node alias、relation、caption、周辺HTMLは変更していない。
- canonical R/D/P byte-identical files: 27/27。
- unchanged supplemental Artifact files: 6/6。`adoption-plan.md` は package path normalization のみ変更した。
- unchanged explanatory HTML files: 5/5。declared PlantUML-only repair files: 4/4。
- rebuilt root control files: 5/5。
- unexpected semantic changes: 0。

## Package self-review

| Invariant | Result | Evidence |
| --- | --- | --- |
| 48 regular files | PASS | ZIP payload と manifest coverage は48 files、`CHECKSUMS.sha256` は自身以外の47 files。 |
| one Epic invariant | PASS | Initiative 1件、`epic-00002` 1件だけを保持。 |
| seven vertical Issues | PASS | 7 Issue の各 R/D/P は byte-identical。各 slice は CLI、source acquisition、domain analysis、JSON、PlantUML、diagnostic、acceptance test を end-to-end で所有。 |
| dependency DAG | PASS | semantic key `ISSUE-01`..`ISSUE-07` の既存 edge を保持し、unknown node と cycle がない。 |
| cross-scope traceability | PASS | `traceability-matrix.md` と全 Issue trace/test ID を再照合。 |
| baseline preservation | PASS | `SOURCE-BASELINE.json` の repository canonical paths、SHA-256、Git blob SHA-1 を変更していない。 |
| lowercase path contract | PASS | Issue directory prefixesと全 internal package path referenceは lowercase `issue-NN-*`。旧 uppercase-prefix package path reference は0件。 |
| planned path honesty | PASS | production source不存在という baseline と planned path/symbol 表記を byte-identical R/D/P で保持。 |
| security/redaction | PASS（仕様） | read-only Git、no execution、source body/comment/literal/secret/absolute path exclusion、SQL default redaction契約を保持。 |
| product HTML exclusion | PASS | Product R/D/P に HTML runtime output/command/schema/publication を導入していない。9 HTML は specification evidence。 |
| UTF-8/LF/whitespace/placeholders | PASS | 48 files を全件検査し、UTF-8、LF、final LF、trailing whitespaceなし、既知placeholderなし。 |
| ZIP safety | PASS | traversal、absolute path、backslash、symlink、duplicate entryなし。CRC と extracted bytes を照合。 |

## Explanation HTML validation

Static contract は添付の exact `validate-plantuml-html.mjs` の static phase を9 filesすべてに対して実行した。さらに全 PlantUML source について、quoted label が physical line を跨がないこと、`@startuml`/`@enduml` が各1件であること、remote include/import がないことを検査した。

| HTML | v2 static contract | original ZIP browser finding | v2 source repair | v2 browser/zoom |
| --- | --- | --- | --- | --- |
| `package/epic/explanation.html` | PASS | FAIL（hard acceptance failure） | quoted multiline label を `\n` escape へ修復 | 未実施 |
| `package/initiative/explanation.html` | PASS | PASS | なし | 未実施 |
| `package/issues/issue-01-generate-python-structure-snapshots/explanation.html` | PASS | PASS | なし | 未実施 |
| `package/issues/issue-02-compare-python-structure-changes-safely/explanation.html` | PASS | PASS | なし | 未実施 |
| `package/issues/issue-03-generate-sqlalchemy-er-snapshots/explanation.html` | PASS | FAIL（hard acceptance failure） | quoted multiline label を `\n` escape へ修復 | 未実施 |
| `package/issues/issue-04-compare-sqlalchemy-er-changes/explanation.html` | PASS | FAIL（hard acceptance failure） | quoted multiline label を `\n` escape へ修復 | 未実施 |
| `package/issues/issue-05-generate-nextjs-component-snapshots/explanation.html` | PASS | PASS | なし | 未実施 |
| `package/issues/issue-06-compare-nextjs-component-changes/explanation.html` | PASS | FAIL（hard acceptance failure） | quoted multiline label を `\n` escape へ修復 | 未実施 |
| `package/issues/issue-07-run-unified-multi-domain-structure-comparison/explanation.html` | PASS | PASS | なし | 未実施 |

- static contract: 9/9 PASS。
- repaired PlantUML source balance gate: 9/9 PASS。
- v2 browser rendering / diagnostic SVG rejection / zoom interaction: **未実施**。この生成環境では pinned `unpkg.com` runtime を DNS 解決できないため、browser success は主張しない。
- supplied local findings にある original ZIP の既知4 failure は hard failure として扱い、該当 source を修復した。v2 の最終 browser acceptance は次の portable rerun gate で確認する。

### Portable browser rerun

network access と Chrome/Chromium/Edge が利用できる環境で、添付 validator を `validate-plantuml-html.mjs` として ZIP root に置き、`MANIFEST.json` の `validation.html_results[].rerun_command` を実行する。9件すべてが static、browser、zoom を PASS するまで adoption gate を閉じない。

## Assumptions and uncertainty

- production dependency の exact version は各 Issue 実装時に license review と lockfile で固定する。本 package は pin/license/offline policy を保持し、future version を推測しない。
- planned path と symbol は baseline scaffold に production source がないため implementation-ready candidate である。layout を material に変える場合は canonical Design/Plan を先に更新する。
- legacy reference の license file は supplied evidence にない。直接 code copy を行う場合は独立した license/provenance approval と CodeStructureViz-owned regression test が必要である。
- browser validation未実施は仕様内容の変更ではなく、v2 adoption の外部実行 gate である。

## Local adoption gates

1. `SOURCE-BASELINE.json` の repository、branch、full SHA、destination SHA-256 を再確認する。
2. ZIP root で `sha256sum -c CHECKSUMS.sha256` または同等 command を実行する。
3. `MANIFEST.json` の9件の browser rerun command をすべて実行し、browser/zoom PASS を確認する。
4. unchanged SpecDock baseline を validate し、`FILE-OPERATIONS.md` の phase 順に適用して各 phase 後に再度 validate する。
5. R/D/P semantics を独立 review し、Codex/user workflow で採否を判断する。ZIP生成は repository integration、Issue creation、tracker publication、implementation completionを意味しない。
